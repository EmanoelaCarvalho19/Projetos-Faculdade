package Controller;

import Modelos.Pessoa;
import Interfaces.IPessoaDAO;
import Conects.MySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PessoaController implements IPessoaDAO {

    @Override
    public Pessoa Save(Pessoa pessoa) {
        if (pessoa == null) {
            throw new IllegalArgumentException("O objeto de pessoa não pode ser nulo.");
        }
        if (pessoa.getId() == null || pessoa.getId() == 0) {
            return this.Insert(pessoa);
        } else {
            this.Update(pessoa);
            return pessoa;
        }
    }

    @Override
    public Pessoa Insert(Pessoa pessoa) {
        final String sql = "INSERT INTO pessoa (id_enderecamento, numero_endereco, complemento_endereco, telefone, cliente_desde, situacao) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setLong(1, pessoa.getIdEnderecamento());
            stmt.setString(2, pessoa.getNumeroEndereco());
            stmt.setString(3, pessoa.getComplementoEndereco());
            stmt.setString(4, pessoa.getTelefone());
            stmt.setDate(5, pessoa.getClienteDesde());
            stmt.setString(6, pessoa.getSituacao());

            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        pessoa.setId(generatedKeys.getLong(1));
                        return pessoa;
                    }
                }
            }
            return null;

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir pessoa: " + e.getMessage(), e);
        }
    }

    @Override
    public void Update(Pessoa pessoa) {
        final String sql = "UPDATE pessoa SET id_enderecamento = ?, numero_endereco = ?, complemento_endereco = ?, telefone = ?, cliente_desde = ?, situacao = ? WHERE id = ?";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, pessoa.getIdEnderecamento());
            stmt.setString(2, pessoa.getNumeroEndereco());
            stmt.setString(3, pessoa.getComplementoEndereco());
            stmt.setString(4, pessoa.getTelefone());
            stmt.setDate(5, pessoa.getClienteDesde());
            stmt.setString(6, pessoa.getSituacao());
            stmt.setLong(7, pessoa.getId());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar pessoa: " + e.getMessage(), e);
        }
    }

    @Override
    public Pessoa Find(Long id) {
        final String sql = "SELECT * FROM pessoa WHERE id = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return instanciarPessoa(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar pessoa por ID: " + e.getMessage(), e);
        }
        return null;
    }

    @Override
    public List<Pessoa> FindAll() {
        final String sql = "SELECT * FROM pessoa ORDER BY id";
        List<Pessoa> lista = new ArrayList<>();

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lista.add(instanciarPessoa(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar todas as pessoas: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public void Delete(Long id) {
        final String sql = "DELETE FROM pessoa WHERE id = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            // Se houver uma restrição de chave estrangeira, a deleção pode falhar.
            throw new RuntimeException("Erro ao deletar pessoa: " + e.getMessage(), e);
        }
    }

    @Override
    public void Delete(Pessoa pessoa) {
        if (pessoa != null && pessoa.getId() != null) {
            this.Delete(pessoa.getId());
        }
    }
    

    private Pessoa instanciarPessoa(ResultSet rs) throws SQLException {
        Pessoa pessoa = new Pessoa();
        pessoa.setId(rs.getLong("id"));
        pessoa.setIdEnderecamento(rs.getLong("id_enderecamento"));
        pessoa.setNumeroEndereco(rs.getString("numero_endereco"));
        pessoa.setComplementoEndereco(rs.getString("complemento_endereco"));
        pessoa.setTelefone(rs.getString("telefone"));
        pessoa.setClienteDesde(rs.getDate("cliente_desde"));
        pessoa.setSituacao(rs.getString("situacao"));
        return pessoa;
    }
}