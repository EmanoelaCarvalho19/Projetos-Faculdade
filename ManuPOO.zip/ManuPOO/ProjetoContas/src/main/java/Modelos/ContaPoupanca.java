package Modelos;

public class ContaPoupanca {
	
	private Long id;
	private String indiceReajuste;

	public ContaPoupanca(Long id, String indiceReajuste) {
		this.id = id;
		this.indiceReajuste = indiceReajuste;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIndiceReajuste() {
		return indiceReajuste;
	}

	public void setIndiceReajuste(String indiceReajuste) {
		this.indiceReajuste = indiceReajuste;
	}
}
