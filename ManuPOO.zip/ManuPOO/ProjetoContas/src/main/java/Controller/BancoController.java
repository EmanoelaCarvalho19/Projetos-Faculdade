package Controller;

import Modelos.Banco;
import Interfaces.IBancoDAO;
import Conects.MySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class BancoController implements IBancoDAO {

    @Override
    public Banco Save(Banco banco) {
        if (banco.getId() == null || banco.getId() == 0) {
            return this.Insert(banco);
        } else {
            this.Update(banco);
            return banco;
        }
    }

    @Override
    public Banco Insert(Banco banco) {
        final String sql = "INSERT INTO banco (codigo_febraban, nome, mascara_conta) VALUES (?, ?, ?)";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, banco.getCodigoFebraban());
            stmt.setString(2, banco.getNome());
            stmt.setString(3, banco.getMascaraConta());

            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        banco.setId(generatedKeys.getLong(1));
                        return banco;
                    }
                }
            }
            return null;

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir banco: " + e.getMessage(), e);
        }
    }

    @Override
    public void Update(Banco banco) {
        final String sql = "UPDATE banco SET codigo_febraban = ?, nome = ?, mascara_conta = ? WHERE id = ?";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, banco.getCodigoFebraban());
            stmt.setString(2, banco.getNome());
            stmt.setString(3, banco.getMascaraConta());
            stmt.setLong(4, banco.getId());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar banco: " + e.getMessage(), e);
        }
    }

    @Override
    public Banco Find(Long id) {
        final String sql = "SELECT * FROM banco WHERE id = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return instanciarBanco(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar banco por ID: " + e.getMessage(), e);
        }
        return null;
    }

    @Override
    public List<Banco> FindAll() {
        final String sql = "SELECT * FROM banco ORDER BY codigo_febraban";
        List<Banco> lista = new ArrayList<>();

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lista.add(instanciarBanco(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar todos os bancos: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public void Delete(Long id) {
        final String sql = "DELETE FROM banco WHERE id = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {

            throw new RuntimeException("Erro ao deletar banco. Verifique se não há agências associadas a ele. " + e.getMessage(), e);
        }
    }
    
    private Banco instanciarBanco(ResultSet rs) throws SQLException {
        Banco banco = new Banco();
        banco.setId(rs.getLong("id"));
        banco.setCodigoFebraban(rs.getString("codigo_febraban"));
        banco.setNome(rs.getString("nome"));
        banco.setMascaraConta(rs.getString("mascara_conta"));
        return banco;
    }
}
