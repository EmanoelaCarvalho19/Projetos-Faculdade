package Controller;

import Modelos.PessoaFisica;
import Interfaces.IPessoaFisicaDAO;
import Conects.MySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PessoaFisicaController implements IPessoaFisicaDAO {

    @Override
    public PessoaFisica Save(PessoaFisica pessoaFisica) {
        // Para esta entidade, não há um ID autoincrementado. A existência é
        // verificada pela busca do id_pessoa.
        if (this.Find(pessoaFisica.getIdPessoa()) != null) {
            this.Update(pessoaFisica);
        } else {
            this.Insert(pessoaFisica);
        }
        return pessoaFisica;
    }

    @Override
    public PessoaFisica Insert(PessoaFisica pf) {
        final String sql = "INSERT INTO pessoa_fisica (id_pessoa, cpf, nome_registro, nome_social, data_nascimento, sexo, renda_mensal) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, pf.getIdPessoa());
            stmt.setString(2, pf.getCpf());
            stmt.setString(3, pf.getNomeRegistro());
            stmt.setString(4, pf.getNomeSocial());
            stmt.setDate(5, pf.getDataNascimento());
            stmt.setString(6, pf.getSexo());
            stmt.setBigDecimal(7, pf.getRendaMensal());

            stmt.executeUpdate();
            return pf;

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir pessoa física: " + e.getMessage(), e);
        }
    }

    @Override
    public void Update(PessoaFisica pf) {
        final String sql = "UPDATE pessoa_fisica SET cpf = ?, nome_registro = ?, nome_social = ?, data_nascimento = ?, sexo = ?, renda_mensal = ? WHERE id_pessoa = ?";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, pf.getCpf());
            stmt.setString(2, pf.getNomeRegistro());
            stmt.setString(3, pf.getNomeSocial());
            stmt.setDate(4, pf.getDataNascimento());
            stmt.setString(5, pf.getSexo());
            stmt.setBigDecimal(6, pf.getRendaMensal());
            stmt.setLong(7, pf.getIdPessoa());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar pessoa física: " + e.getMessage(), e);
        }
    }

    @Override
    public PessoaFisica Find(Long idPessoa) {
        final String sql = "SELECT * FROM pessoa_fisica WHERE id_pessoa = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, idPessoa);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return instanciarPessoaFisica(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar pessoa física por ID: " + e.getMessage(), e);
        }
        return null;
    }

    @Override
    public List<PessoaFisica> FindAll() {
        final String sql = "SELECT * FROM pessoa_fisica ORDER BY id_pessoa";
        List<PessoaFisica> lista = new ArrayList<>();

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lista.add(instanciarPessoaFisica(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar todas as pessoas físicas: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public void Delete(Long idPessoa) {
        final String sql = "DELETE FROM pessoa_fisica WHERE id_pessoa = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, idPessoa);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar pessoa física: " + e.getMessage(), e);
        }
    }

    private PessoaFisica instanciarPessoaFisica(ResultSet rs) throws SQLException {
        PessoaFisica pf = new PessoaFisica();
        pf.setIdPessoa(rs.getLong("id_pessoa"));
        pf.setCpf(rs.getString("cpf"));
        pf.setNomeRegistro(rs.getString("nome_registro"));
        pf.setNomeSocial(rs.getString("nome_social"));
        pf.setDataNascimento(rs.getDate("data_nascimento"));
        pf.setSexo(rs.getString("sexo"));
        pf.setRendaMensal(rs.getBigDecimal("renda_mensal"));
        return pf;
    }
}