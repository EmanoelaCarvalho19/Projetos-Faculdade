package Conects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MySQL {

 
    private static final String HOST = "localhost";
    private static final String PORT = "3306";
    private static final String DATABASE = "bdamanu"; 
    private static final String USER = "root";
    private static final String PASSWORD = ""; 


    private static final String URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE + 
                                      "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";

    public static Connection Conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Erro: Driver JDBC do MySQL não encontrado! Verifique se o conector .jar está no seu projeto.", e);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao conectar ao banco de dados: " + e.getMessage(), e);
        }
    }
    
    public static void Desconectar(Connection conexao, PreparedStatement comando) {
        try {
            if (comando != null) {
                comando.close();
            }
        } catch (SQLException e) {
            System.err.println("Erro ao fechar o PreparedStatement: " + e.getMessage());
        }
        
        try {
            if (conexao != null) {
                conexao.close();
            }
        } catch (SQLException e) {
            System.err.println("Erro ao fechar a Conexão: " + e.getMessage());
        }
    }
}