package br.com.unisenai.ProjetoContas;

import Controller.AgenciaController;
import Controller.ContaBancariaController;
import Controller.PessoaFisicaController;
import Controller.PessoaJuridicaController;
import Modelos.Agencia;
import Modelos.ContaBancaria;
import Modelos.PessoaFisica;
import Modelos.PessoaJuridica;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class ContaBancariaTest {

    private static final ContaBancariaController dao = new ContaBancariaController();
    private static final AgenciaController agenciaDAO = new AgenciaController();
    private static final PessoaFisicaController pfDao = new PessoaFisicaController();
    private static final PessoaJuridicaController pjDao = new PessoaJuridicaController();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;

        while (opcao != 0) {
            exibirMenu();
            try {
                opcao = scanner.nextInt();
                scanner.nextLine();

                switch (opcao) {
                    case 1:
                        listarTodos();
                        break;
                    case 2:
                        inserirNovo();
                        break;
                    case 3:
                        deletar();
                        break;
                    case 0:
                        System.out.println("\n👋 Encerrando o sistema. Até logo!");
                        break;
                    default:
                        System.out.println("\n❌ Opção inválida! Por favor, tente novamente.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("\n❌ Erro de entrada! Por favor, digite apenas números.");
                scanner.nextLine();
                opcao = -1;
            }
            if (opcao != 0) {
                pressioneEnterParaContinuar();
            }
        }
        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("\n--- 💳 MENU DE GERENCIAMENTO DE CONTAS BANCÁRIAS ---");
        System.out.println("1. Listar todas as contas");
        System.out.println("2. Abrir nova conta bancária");
        System.out.println("3. Encerrar conta bancária");
        System.out.println("--------------------------------------------------");
        System.out.println("0. Sair");
        System.out.print("➡️  Escolha uma opção: ");
    }

    private static void listarTodos() {
        System.out.println("\n--- LISTA DE TODAS AS CONTAS BANCÁRIAS ---");
        List<ContaBancaria> contas = dao.FindAll();
        if (contas.isEmpty()) {
            System.out.println("ℹ️ Nenhuma conta cadastrada no momento.");
        } else {
            contas.forEach(System.out::println);
        }
    }

    private static void inserirNovo() {
        System.out.println("\n--- ABRIR NOVA CONTA BANCÁRIA ---");
        
        boolean agenciasExistem = listarAgenciasDisponiveis();
        boolean titularesExistem = listarTitularesDisponiveis();

        if (!agenciasExistem || !titularesExistem) {
            System.out.println("\n❌ Faltam dados para abrir uma conta!");
            if (!agenciasExistem) System.out.println("   -> Cadastre pelo menos uma Agência primeiro.");
            if (!titularesExistem) System.out.println("   -> Cadastre pelo menos uma Pessoa (Física ou Jurídica) primeiro.");
            return;
        }

        ContaBancaria novaConta = new ContaBancaria();

        try {
            System.out.println("\nℹ️ Escolha os IDs das listas acima para abrir a conta.");
            
            System.out.print("ID da Agência: ");
            novaConta.setAgenciaId(scanner.nextLong());
            
            System.out.print("ID do 1º Titular: ");
            novaConta.setTitular1Id(scanner.nextLong());
            scanner.nextLine();
            
            System.out.print("Deseja adicionar um 2º titular? (S/N): ");
            if(scanner.nextLine().equalsIgnoreCase("S")){
                System.out.print("ID do 2º Titular: ");
                novaConta.setTitular2Id(scanner.nextLong());
                scanner.nextLine();
            }

            System.out.print("Data de Abertura (AAAA-MM-DD): ");
            novaConta.setDataAbertura(converterStringParaSqlDate(scanner.nextLine()));
            
            System.out.print("Senha da conta (numérica): ");
            novaConta.setSenha(scanner.nextLine());

            novaConta.setSaldo(BigDecimal.ZERO);
            novaConta.setSituacao("Ativa");

            ContaBancaria contaSalva = dao.Save(novaConta);
            
            if (contaSalva != null) {
                System.out.println("\n✅ Conta aberta com sucesso!\n" + contaSalva);
            } else {
                 System.out.println("\n❌ Falha ao abrir a conta. Verifique se os IDs da Agência e Titular(es) estão corretos e existem no banco.");
            }

        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido. A operação foi cancelada.");
            scanner.nextLine();
        } catch (ParseException e) {
            System.out.println("❌ Formato de data inválido! Use AAAA-MM-DD. A operação foi cancelada.");
        } catch (Exception e) {
            System.out.println("\n❌ OCORREU UM ERRO INESPERADO: " + e.getMessage());
        }
    }
    
    private static boolean listarAgenciasDisponiveis() {
        System.out.println("\n--- AGÊNCIAS DISPONÍVEIS ---");
        List<Agencia> agencias = agenciaDAO.FindAll();
        if (agencias.isEmpty()) { return false; }
        agencias.forEach(ag -> System.out.println("ID: " + ag.getId() + " | Nome: " + ag.getNome()));
        return true;
    }

    private static boolean listarTitularesDisponiveis() {
        System.out.println("\n--- TITULARES DISPONÍVEIS ---");
        List<PessoaFisica> fisicas = pfDao.FindAll();
        List<PessoaJuridica> juridicas = pjDao.FindAll();
        if (fisicas.isEmpty() && juridicas.isEmpty()) { return false; }
        fisicas.forEach(pf -> System.out.println("ID: " + pf.getIdPessoa() + " | Nome: " + pf.getNomeRegistro()));
        juridicas.forEach(pj -> System.out.println("ID: " + pj.getIdPessoa() + " | Razão Social: " + pj.getRazaoSocial()));
        return true;
    }

    private static void deletar() {
         System.out.print("\nDigite o ID da conta que deseja encerrar: ");
        try {
            Long id = scanner.nextLong();
            scanner.nextLine();
            ContaBancaria conta = dao.Find(id);
            if (conta == null) {
                System.out.println("❌ Conta com ID " + id + " não encontrada.");
                return;
            }

            System.out.println("Você tem certeza que deseja encerrar a seguinte conta?");
            System.out.println(conta);
            System.out.print("Esta ação é irreversível. Digite 'S' para confirmar: ");
            String confirmacao = scanner.nextLine();
            
            if (confirmacao.equalsIgnoreCase("S")) {
                dao.Delete(id);
                System.out.println("✅ Conta encerrada com sucesso.");
            } else {
                System.out.println("ℹ️ Operação cancelada.");
            }
        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido.");
            scanner.nextLine();
        }
    }
    
    private static Date converterStringParaSqlDate(String dataStr) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return new java.sql.Date(format.parse(dataStr).getTime());
    }

    private static void pressioneEnterParaContinuar() {
        System.out.print("\nPressione [Enter] para continuar...");
        scanner.nextLine();
    }
}