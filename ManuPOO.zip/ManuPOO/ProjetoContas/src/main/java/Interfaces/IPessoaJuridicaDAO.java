package Interfaces;

import Modelos.PessoaJuridica;
import java.util.List;


public interface IPessoaJuridicaDAO {

    PessoaJuridica Save(PessoaJuridica pessoaJuridica);

    PessoaJuridica Insert(PessoaJuridica pessoaJuridica);

    void Update(PessoaJuridica pessoaJuridica);

    PessoaJuridica Find(Long idPessoa);

    List<PessoaJuridica> FindAll();

    void Delete(Long idPessoa);
}