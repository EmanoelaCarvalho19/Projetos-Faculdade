package Controller;

import Modelos.Agencia;
import Interfaces.IAgenciaDAO;
import Conects.MySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AgenciaController implements IAgenciaDAO {

    @Override
    public Agencia Save(Agencia agencia) {
        if (agencia.getId() == null || agencia.getId() == 0) {
            return this.Insert(agencia);
        } else {
            this.Update(agencia);
            return agencia;
        }
    }

    @Override
    public Agencia Insert(Agencia agencia) {
        final String sql = "INSERT INTO agencia (banco_id, id_enderecamento, nome, telefone, situacao) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setLong(1, agencia.getBancoId());
            stmt.setLong(2, agencia.getIdEnderecamento());
            stmt.setString(3, agencia.getNome());
            stmt.setString(4, agencia.getTelefone());
            stmt.setString(5, agencia.getSituacao());

            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        agencia.setId(generatedKeys.getLong(1));
                        return agencia;
                    }
                }
            }
            return null;

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir agência: " + e.getMessage(), e);
        }
    }

    @Override
    public void Update(Agencia agencia) {
        final String sql = "UPDATE agencia SET banco_id = ?, id_enderecamento = ?, nome = ?, telefone = ?, situacao = ? WHERE id = ?";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, agencia.getBancoId());
            stmt.setLong(2, agencia.getIdEnderecamento());
            stmt.setString(3, agencia.getNome());
            stmt.setString(4, agencia.getTelefone());
            stmt.setString(5, agencia.getSituacao());
            stmt.setLong(6, agencia.getId());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar agência: " + e.getMessage(), e);
        }
    }

    @Override
    public Agencia Find(Long id) {
        final String sql = "SELECT * FROM agencia WHERE id = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return instanciarAgencia(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar agência por ID: " + e.getMessage(), e);
        }
        return null;
    }

    @Override
    public List<Agencia> FindAll() {
        final String sql = "SELECT * FROM agencia ORDER BY nome";
        List<Agencia> lista = new ArrayList<>();

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lista.add(instanciarAgencia(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar todas as agências: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public void Delete(Long id) {
        final String sql = "DELETE FROM agencia WHERE id = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar agência. Verifique se não há contas bancárias associadas a ela. " + e.getMessage(), e);
        }
    }
    
    private Agencia instanciarAgencia(ResultSet rs) throws SQLException {
        Agencia agencia = new Agencia();
        agencia.setId(rs.getLong("id"));
        agencia.setBancoId(rs.getLong("banco_id"));
        agencia.setIdEnderecamento(rs.getLong("id_enderecamento"));
        agencia.setNome(rs.getString("nome"));
        agencia.setTelefone(rs.getString("telefone"));
        agencia.setSituacao(rs.getString("situacao"));
        return agencia;
    }
}