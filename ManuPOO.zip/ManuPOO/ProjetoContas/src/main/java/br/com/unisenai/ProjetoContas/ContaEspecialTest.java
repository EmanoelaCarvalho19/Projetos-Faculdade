package br.com.unisenai.ProjetoContas;

import Controller.ContaBancariaController;
import Controller.ContaEspecialController;
import Modelos.ContaBancaria;
import Modelos.ContaEspecial;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ContaEspecialTest {

    private static final ContaEspecialController dao = new ContaEspecialController();
    private static final ContaBancariaController contaBancariaDAO = new ContaBancariaController(); // Para listar contas
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;

        while (opcao != 0) {
            exibirMenu();
            try {
                opcao = scanner.nextInt();
                scanner.nextLine();

                switch (opcao) {
                    case 1:
                        listarContasEspeciais();
                        break;
                    case 2:
                        tornarContaEspecial();
                        break;
                    case 3:
                        removerLimiteEspecial();
                        break;
                    case 0:
                        System.out.println("\n👋 Encerrando o sistema. Até logo!");
                        break;
                    default:
                        System.out.println("\n❌ Opção inválida! Por favor, tente novamente.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("\n❌ Erro de entrada! Por favor, digite apenas números.");
                scanner.nextLine();
                opcao = -1;
            }
            if (opcao != 0) {
                pressioneEnterParaContinuar();
            }
        }
        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("\n--- ✨ MENU DE GERENCIAMENTO DE CONTAS ESPECIAIS ---");
        System.out.println("1. Listar todas as contas especiais (com limites)");
        System.out.println("2. Atribuir/Atualizar limite de uma conta");
        System.out.println("3. Remover status de conta especial");
        System.out.println("--------------------------------------------------");
        System.out.println("0. Sair");
        System.out.print("➡️  Escolha uma opção: ");
    }

    private static void listarContasEspeciais() {
        System.out.println("\n--- LISTA DE CONTAS ESPECIAIS ---");
        List<ContaEspecial> contasEspeciais = dao.FindAll();
        if (contasEspeciais.isEmpty()) {
            System.out.println("ℹ️ Nenhuma conta especial cadastrada no momento.");
        } else {
            for (ContaEspecial ce : contasEspeciais) {
                ContaBancaria cb = contaBancariaDAO.Find(ce.getContaId());
                System.out.println("------------------------------------");
                System.out.println("ID da Conta: " + ce.getContaId() + " | Titular 1 ID: " + cb.getTitular1Id());
                System.out.println("Limite de Crédito: R$ " + ce.getLimiteCredito());
                System.out.println("Vencimento do Limite: " + ce.getVencimentoLimite());
                System.out.println("------------------------------------");
            }
        }
    }

    private static void tornarContaEspecial() {
        System.out.println("\n--- ATRIBUIR/ATUALIZAR LIMITE ---");
        
        // Passo 1: Listar todas as contas bancárias para o usuário escolher
        System.out.println("Selecione uma conta bancária da lista abaixo para gerenciar o limite:");
        List<ContaBancaria> todasAsContas = contaBancariaDAO.FindAll();
        if (todasAsContas.isEmpty()) {
            System.out.println("❌ Não há contas bancárias cadastradas. Crie uma conta primeiro.");
            return;
        }
        todasAsContas.forEach(c -> System.out.println("ID: " + c.getId() + " | Titular 1: " + c.getTitular1Id() + " | Saldo: " + c.getSaldo()));

        ContaEspecial novaContaEspecial = new ContaEspecial();
        try {
            System.out.print("\nDigite o ID da conta que receberá o limite: ");
            long idConta = scanner.nextLong();
            novaContaEspecial.setContaId(idConta);
            scanner.nextLine();

            System.out.print("Digite o valor do limite de crédito (ex: 1500.00): ");
            novaContaEspecial.setLimiteCredito(scanner.nextBigDecimal());
            scanner.nextLine();
            
            System.out.print("Digite a data de vencimento do limite (AAAA-MM-DD): ");
            novaContaEspecial.setVencimentoLimite(converterStringParaSqlDate(scanner.nextLine()));

            dao.Save(novaContaEspecial);
            System.out.println("\n✅ Limite da conta ID " + idConta + " salvo com sucesso!");

        } catch (InputMismatchException e) {
            System.out.println("❌ Entrada inválida. A operação foi cancelada.");
            scanner.nextLine();
        } catch (ParseException e) {
            System.out.println("❌ Formato de data inválido! Use AAAA-MM-DD. A operação foi cancelada.");
        } catch (Exception e) {
            System.out.println("❌ Ocorreu um erro inesperado: " + e.getMessage());
        }
    }
    
    private static void removerLimiteEspecial() {
        System.out.println("\n--- REMOVER STATUS DE CONTA ESPECIAL ---");
        listarContasEspeciais(); // Mostra as contas que podem ter o status removido
        
        System.out.print("\nDigite o ID da conta para remover o limite: ");
        try {
            long id = scanner.nextLong();
            scanner.nextLine();
            
            if (dao.Find(id) == null) {
                 System.out.println("❌ Conta com ID " + id + " não é uma conta especial.");
                 return;
            }

            System.out.print("Tem certeza que deseja remover o limite da conta " + id + "? (S/N): ");
            if (scanner.nextLine().equalsIgnoreCase("S")) {
                dao.Delete(id);
                System.out.println("✅ Status de conta especial removido com sucesso.");
            } else {
                System.out.println("ℹ️ Operação cancelada.");
            }
        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido.");
            scanner.nextLine();
        }
    }
    
    private static Date converterStringParaSqlDate(String dataStr) throws ParseException {
        if(dataStr == null || dataStr.trim().isEmpty()){
            return null;
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date parsed = format.parse(dataStr);
        return new java.sql.Date(parsed.getTime());
    }

    private static void pressioneEnterParaContinuar() {
        System.out.print("\nPressione [Enter] para continuar...");
        scanner.nextLine();
    }
}
