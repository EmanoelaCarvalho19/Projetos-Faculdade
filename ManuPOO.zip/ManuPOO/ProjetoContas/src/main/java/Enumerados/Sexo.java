package Enumerados;

public enum Sexo {
    MasculinoCis ("MC"),
    FemininoCis ("FC"),
    MasculinoTrans ("MT"),
    FemininoTrans ("FT"),
    NaoBinario ("NB"),
    Outros ("OT");

    private String siglaSexo;
    private Sexo(String sexo){
        this.siglaSexo = sexo;
    }

    public String getSiglaSexo (){
        return this.siglaSexo;
    }
}
