package Modelos;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.Objects;


public class ContaEspecial {

    private Long contaId; 
    private BigDecimal limiteCredito;
    private Date vencimentoLimite;

    public ContaEspecial() {
    }

    public Long getContaId() {
        return contaId;
    }

    public void setContaId(Long contaId) {
        this.contaId = contaId;
    }

    public BigDecimal getLimiteCredito() {
        return limiteCredito;
    }

    public void setLimiteCredito(BigDecimal limiteCredito) {
        this.limiteCredito = limiteCredito;
    }

    public Date getVencimentoLimite() {
        return vencimentoLimite;
    }

    public void setVencimentoLimite(Date vencimentoLimite) {
        this.vencimentoLimite = vencimentoLimite;
    }

    // --- toString, equals, hashCode ---
    @Override
    public String toString() {
        return "ContaEspecial{" +
                "contaId=" + contaId +
                ", limiteCredito=" + limiteCredito +
                ", vencimentoLimite=" + vencimentoLimite +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ContaEspecial that = (ContaEspecial) o;
        return Objects.equals(contaId, that.contaId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(contaId);
    }
}