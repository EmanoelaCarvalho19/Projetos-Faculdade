package Controller;

import Modelos.ContaEspecial;
import Interfaces.IContaEspecialDAO;
import Conects.MySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class ContaEspecialController implements IContaEspecialDAO {

    @Override
    public void Save(ContaEspecial contaEspecial) {
        if (this.Find(contaEspecial.getContaId()) != null) {
            this.Update(contaEspecial);
        } else {
            this.Insert(contaEspecial);
        }
    }

    @Override
    public void Insert(ContaEspecial ce) {
        final String sql = "INSERT INTO conta_especial (conta_id, limite_credito, vencimento_limite) VALUES (?, ?, ?)";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, ce.getContaId());
            stmt.setBigDecimal(2, ce.getLimiteCredito());
            stmt.setDate(3, ce.getVencimentoLimite());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir dados da conta especial: " + e.getMessage(), e);
        }
    }

    @Override
    public void Update(ContaEspecial ce) {
        final String sql = "UPDATE conta_especial SET limite_credito = ?, vencimento_limite = ? WHERE conta_id = ?";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setBigDecimal(1, ce.getLimiteCredito());
            stmt.setDate(2, ce.getVencimentoLimite());
            stmt.setLong(3, ce.getContaId());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar dados da conta especial: " + e.getMessage(), e);
        }
    }

    @Override
    public ContaEspecial Find(Long contaId) {
        final String sql = "SELECT * FROM conta_especial WHERE conta_id = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, contaId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return instanciarContaEspecial(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar conta especial por ID: " + e.getMessage(), e);
        }
        return null;
    }

    @Override
    public List<ContaEspecial> FindAll() {
        final String sql = "SELECT * FROM conta_especial ORDER BY conta_id";
        List<ContaEspecial> lista = new ArrayList<>();

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lista.add(instanciarContaEspecial(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar todas as contas especiais: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public void Delete(Long contaId) {
        final String sql = "DELETE FROM conta_especial WHERE conta_id = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, contaId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar dados da conta especial: " + e.getMessage(), e);
        }
    }
    
    private ContaEspecial instanciarContaEspecial(ResultSet rs) throws SQLException {
        ContaEspecial ce = new ContaEspecial();
        ce.setContaId(rs.getLong("conta_id"));
        ce.setLimiteCredito(rs.getBigDecimal("limite_credito"));
        ce.setVencimentoLimite(rs.getDate("vencimento_limite"));
        return ce;
    }
}