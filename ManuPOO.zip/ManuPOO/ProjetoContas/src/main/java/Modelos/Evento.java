package Modelos;

public class Evento {

	private Long id;
	private String descricao;
	private String tipoMovimentacao;
	private boolean requerUsoSenha;
	private String situacao;

	public Evento(Long id, String descricao, String tipoMovimentacao, boolean requerUsoSenha, String situacao) {
		this.id = id;
		this.descricao = descricao;
		this.tipoMovimentacao = tipoMovimentacao;
		this.requerUsoSenha = requerUsoSenha;
		this.situacao = situacao;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getTipoMovimentacao() {
		return tipoMovimentacao;
	}

	public void setTipoMovimentacao(String tipoMovimentacao) {
		this.tipoMovimentacao = tipoMovimentacao;
	}

	public boolean isRequerUsoSenha() {
		return requerUsoSenha;
	}

	public void setRequerUsoSenha(boolean requerUsoSenha) {
		this.requerUsoSenha = requerUsoSenha;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
}
