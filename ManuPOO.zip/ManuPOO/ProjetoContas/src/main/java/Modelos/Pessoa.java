package Modelos;

import java.sql.Date;
import java.util.Objects;


public class Pessoa {

    private Long id;
    private Long idEnderecamento; 
    private String numeroEndereco;
    private String complementoEndereco;
    private String telefone;
    private Date clienteDesde;
    private String situacao;


    public Pessoa() {
    }

 
    public Pessoa(Long id, Long idEnderecamento, String numeroEndereco, String complementoEndereco, String telefone, Date clienteDesde, String situacao) {
        this.id = id;
        this.idEnderecamento = idEnderecamento;
        this.numeroEndereco = numeroEndereco;
        this.complementoEndereco = complementoEndereco;
        this.telefone = telefone;
        this.clienteDesde = clienteDesde;
        this.situacao = situacao;
    }

    // --- Getters e Setters ---
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIdEnderecamento() {
        return idEnderecamento;
    }

    public void setIdEnderecamento(Long idEnderecamento) {
        this.idEnderecamento = idEnderecamento;
    }

    public String getNumeroEndereco() {
        return numeroEndereco;
    }

    public void setNumeroEndereco(String numeroEndereco) {
        this.numeroEndereco = numeroEndereco;
    }

    public String getComplementoEndereco() {
        return complementoEndereco;
    }

    public void setComplementoEndereco(String complementoEndereco) {
        this.complementoEndereco = complementoEndereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Date getClienteDesde() {
        return clienteDesde;
    }

    public void setClienteDesde(Date clienteDesde) {
        this.clienteDesde = clienteDesde;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }
    
    // --- toString, equals e hashCode ---

    @Override
    public String toString() {
        return "Pessoa{" +
                "id=" + id +
                ", idEnderecamento=" + idEnderecamento +
                ", numeroEndereco='" + numeroEndereco + '\'' +
                ", complementoEndereco='" + complementoEndereco + '\'' +
                ", telefone='" + telefone + '\'' +
                ", clienteDesde=" + clienteDesde +
                ", situacao='" + situacao + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pessoa pessoa = (Pessoa) o;
        return Objects.equals(id, pessoa.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
