package Utilitarios;

public abstract class Utils {
    public static boolean ehCPFValido (String cpf) {
        if (cpf == null || cpf.length() != 11) {
            return false;
        }
        
        return true;
    }
}