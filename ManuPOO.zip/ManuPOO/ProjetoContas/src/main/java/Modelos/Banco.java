package Modelos;

import java.util.Objects;


public class Banco {

    private Long id;
    private String codigoFebraban; 
    private String nome;
    private String mascaraConta; 

    public Banco() {
    }

    // --- Getters e Setters ---
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigoFebraban() {
        return codigoFebraban;
    }

    public void setCodigoFebraban(String codigoFebraban) {
        this.codigoFebraban = codigoFebraban;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMascaraConta() {
        return mascaraConta;
    }

    public void setMascaraConta(String mascaraConta) {
        this.mascaraConta = mascaraConta;
    }

    // --- toString, equals, hashCode ---
    @Override
    public String toString() {
        return "Banco{" +
                "id=" + id +
                ", codigoFebraban='" + codigoFebraban + '\'' +
                ", nome='" + nome + '\'' +
                ", mascaraConta='" + mascaraConta + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Banco banco = (Banco) o;
        return Objects.equals(id, banco.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}