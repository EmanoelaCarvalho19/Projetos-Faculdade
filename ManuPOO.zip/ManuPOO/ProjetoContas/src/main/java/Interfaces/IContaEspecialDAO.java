package Interfaces;

import Modelos.ContaEspecial;
import java.util.List;

public interface IContaEspecialDAO {

    void Save(ContaEspecial contaEspecial);
    void Insert(ContaEspecial contaEspecial);
    void Update(ContaEspecial contaEspecial);
    ContaEspecial Find(Long contaId);
    List<ContaEspecial> FindAll();
    void Delete(Long contaId);
}

