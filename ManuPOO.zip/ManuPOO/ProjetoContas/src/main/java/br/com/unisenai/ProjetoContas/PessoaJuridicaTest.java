package br.com.unisenai.ProjetoContas;

import Controller.PessoaController;
import Controller.PessoaJuridicaController;
import Modelos.Pessoa;
import Modelos.PessoaJuridica;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class PessoaJuridicaTest {


    private static final PessoaController pessoaDAO = new PessoaController();
    private static final PessoaJuridicaController pessoaJuridicaDAO = new PessoaJuridicaController();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;

        while (opcao != 0) {
            exibirMenu();
            try {
                opcao = scanner.nextInt();
                scanner.nextLine(); // Limpa o buffer

                switch (opcao) {
                    case 1:
                        listarTodos();
                        break;
                    case 2:
                        inserirNovo();
                        break;
                    case 3:
                        deletar();
                        break;
                    case 0:
                        System.out.println("\n👋 Encerrando o sistema. Até logo!");
                        break;
                    default:
                        System.out.println("\n❌ Opção inválida! Por favor, tente novamente.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("\n❌ Erro de entrada! Por favor, digite apenas números.");
                scanner.nextLine();
                opcao = -1;
            }
            if (opcao != 0) {
                pressioneEnterParaContinuar();
            }
        }
        scanner.close();
    }
    
    private static void exibirMenu() {
        System.out.println("\n--- 🏢 MENU DE GERENCIAMENTO DE PESSOAS JURÍDICAS ---");
        System.out.println("1. Listar todas as pessoas jurídicas");
        System.out.println("2. Inserir nova pessoa jurídica");
        System.out.println("3. Deletar pessoa jurídica (e a pessoa associada)");
        System.out.println("---------------------------------------------------");
        System.out.println("0. Sair");
        System.out.print("➡️  Escolha uma opção: ");
    }

    private static void listarTodos() {
        System.out.println("\n--- LISTA DE TODAS AS PESSOAS JURÍDICAS ---");
        List<PessoaJuridica> pessoasJuridicas = pessoaJuridicaDAO.FindAll();

        if (pessoasJuridicas.isEmpty()) {
            System.out.println("ℹ️ Nenhuma pessoa jurídica cadastrada no momento.");
        } else {
            for (PessoaJuridica pj : pessoasJuridicas) {
                Pessoa p = pessoaDAO.Find(pj.getIdPessoa());
                System.out.println("\n-------------------------------------------");
                System.out.println("ID Pessoa: " + pj.getIdPessoa());
                System.out.println("Razão Social: " + pj.getRazaoSocial());
                System.out.println("Nome Fantasia: " + pj.getNomeFantasia());
                System.out.println("CNPJ: " + pj.getCnpj());
                if(p != null) {
                    System.out.println("Cliente Desde: " + p.getClienteDesde());
                    System.out.println("Telefone: " + p.getTelefone());
                    System.out.println("ID Endereço: " + p.getIdEnderecamento());
                }
                System.out.println("-------------------------------------------");
            }
        }
    }
    
    private static void inserirNovo() {
        System.out.println("\n--- INSERIR NOVA PESSOA JURÍDICA ---");
        System.out.println("Cadastro em 2 etapas: 1. Dados Gerais | 2. Dados da Empresa");

        Pessoa novaPessoa = new Pessoa();
        PessoaJuridica novaPessoaJuridica = new PessoaJuridica();
        
        try {
            // --- ETAPA 1: DADOS DA 'PESSOA' ---
            System.out.println("\n--- ETAPA 1: DADOS GERAIS (ENDEREÇO E CONTATO) ---");
            System.out.print("ID do Endereçamento (deve existir): ");
            novaPessoa.setIdEnderecamento(scanner.nextLong());
            scanner.nextLine();
            
            System.out.print("Número do endereço: ");
            novaPessoa.setNumeroEndereco(scanner.nextLine());
            
            System.out.print("Telefone de contato: ");
            novaPessoa.setTelefone(scanner.nextLine());
            
            System.out.print("Data de início como cliente (AAAA-MM-DD): ");
            novaPessoa.setClienteDesde(converterStringParaSqlDate(scanner.nextLine()));
            novaPessoa.setSituacao("Ativo");

            Pessoa pessoaSalva = pessoaDAO.Save(novaPessoa);
            if(pessoaSalva == null || pessoaSalva.getId() == null) {
                System.out.println("❌ Erro ao salvar os dados gerais. A operação foi cancelada.");
                return;
            }
            System.out.println("✅ Etapa 1 concluída! ID de Pessoa gerado: " + pessoaSalva.getId());

            // --- ETAPA 2: DADOS DA 'PESSOA JURÍDICA' ---
            System.out.println("\n--- ETAPA 2: DADOS DA EMPRESA ---");
            novaPessoaJuridica.setIdPessoa(pessoaSalva.getId());
            
            System.out.print("CNPJ (14 dígitos, sem formatação): ");
            novaPessoaJuridica.setCnpj(scanner.nextLine());
            
            System.out.print("Razão Social: ");
            novaPessoaJuridica.setRazaoSocial(scanner.nextLine());

            System.out.print("Nome Fantasia (opcional): ");
            novaPessoaJuridica.setNomeFantasia(scanner.nextLine());

            System.out.print("Data de Abertura da Empresa (AAAA-MM-DD): ");
            novaPessoaJuridica.setDataAbertura(converterStringParaSqlDate(scanner.nextLine()));
            
            System.out.print("Capital Social (ex: 50000.00): ");
            novaPessoaJuridica.setCapitalSocial(scanner.nextBigDecimal());
            scanner.nextLine();
            
            pessoaJuridicaDAO.Save(novaPessoaJuridica);
            System.out.println("\n✅ Etapa 2 concluída! Pessoa Jurídica cadastrada com sucesso!");

        } catch (InputMismatchException e) {
            System.out.println("❌ Entrada inválida. A operação foi cancelada.");
            scanner.nextLine();
        } catch (ParseException e) {
            System.out.println("❌ Formato de data inválido! Use AAAA-MM-DD. A operação foi cancelada.");
        } catch (Exception e) {
            System.out.println("❌ Ocorreu um erro inesperado: " + e.getMessage());
        }
    }
    
    private static void deletar() {
        System.out.print("\nDigite o ID da Pessoa que deseja deletar (isso deletará a Pessoa e a Pessoa Jurídica associada): ");
        try {
            Long id = scanner.nextLong();
            scanner.nextLine();
            
            PessoaJuridica pj = pessoaJuridicaDAO.Find(id);
            if (pj == null) {
                System.out.println("❌ Pessoa Jurídica com ID " + id + " não encontrada.");
                return;
            }

            System.out.println("Você tem certeza que deseja deletar a empresa " + pj.getRazaoSocial() + " (CNPJ: " + pj.getCnpj() + ")?");
            System.out.print("Esta ação é irreversível. Digite 'S' para confirmar: ");
            String confirmacao = scanner.nextLine();
            
            if (confirmacao.equalsIgnoreCase("S")) {
                // Deletamos a 'Pessoa', e o ON DELETE CASCADE no banco deleta a 'PessoaJuridica'.
                pessoaDAO.Delete(id);
                System.out.println("✅ Pessoa Jurídica deletada com sucesso.");
            } else {
                System.out.println("ℹ️ Operação cancelada.");
            }
        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido.");
            scanner.nextLine();
        }
    }
    
    private static Date converterStringParaSqlDate(String dataStr) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date parsed = format.parse(dataStr);
        return new java.sql.Date(parsed.getTime());
    }

    private static void pressioneEnterParaContinuar() {
        System.out.print("\nPressione [Enter] para continuar...");
        scanner.nextLine();
    }
}
