package Controller;

import Modelos.ContaBancaria;
import Interfaces.IContaBancariaDAO;
import Conects.MySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class ContaBancariaController implements IContaBancariaDAO {

    @Override
    public ContaBancaria Save(ContaBancaria conta) {
        if (conta.getId() == null || conta.getId() == 0) {
            return this.Insert(conta);
        } else {
            this.Update(conta);
            return conta;
        }
    }

    @Override
    public ContaBancaria Insert(ContaBancaria conta) {
        final String sql = "INSERT INTO conta_bancaria (agencia_id, titular_1, titular_2, data_abertura, saldo, senha, bandeira_cartao, numero_cartao, validade_cartao, cvv, situacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setLong(1, conta.getAgenciaId());
            stmt.setLong(2, conta.getTitular1Id());

            if (conta.getTitular2Id() != null && conta.getTitular2Id() > 0) {
                stmt.setLong(3, conta.getTitular2Id());
            } else {
                stmt.setNull(3, Types.BIGINT);
            }

            stmt.setDate(4, conta.getDataAbertura());
            stmt.setBigDecimal(5, conta.getSaldo());
            stmt.setString(6, conta.getSenha());

            if (conta.getBandeiraCartao() != null) { stmt.setString(7, conta.getBandeiraCartao()); } else { stmt.setNull(7, Types.VARCHAR); }
            if (conta.getNumeroCartao() != null) { stmt.setString(8, conta.getNumeroCartao()); } else { stmt.setNull(8, Types.VARCHAR); }
            if (conta.getValidadeCartao() != null) { stmt.setDate(9, conta.getValidadeCartao()); } else { stmt.setNull(9, Types.DATE); }
            if (conta.getCvv() != null) { stmt.setString(10, conta.getCvv()); } else { stmt.setNull(10, Types.CHAR); }

            // Validação segura para o ENUM 'situacao'
            String situacao = conta.getSituacao();
            if (situacao == null || situacao.trim().isEmpty()) {
                situacao = "Ativa"; // padrão
            } else {
                situacao = situacao.trim();
                if (!situacao.equals("Ativa") && !situacao.equals("Bloqueada") && !situacao.equals("Encerrada")) {
                    throw new IllegalArgumentException("Valor inválido para a situação da conta: " + situacao);
                }
            }
            stmt.setString(11, situacao);

            if (stmt.executeUpdate() > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        conta.setId(rs.getLong(1));
                        return conta;
                    }
                }
            }
            return null;

        } catch (SQLException e) {
            if (e.getErrorCode() == 1452) {
                throw new RuntimeException("FALHA DE CHAVE ESTRANGEIRA (Erro 1452): O ID da Agência ou do Titular não foi encontrado. Verifique se os registros existem.", e);
            }
            throw new RuntimeException("Erro ao inserir conta bancária: " + e.getMessage(), e);
        }
    }

    @Override
    public void Update(ContaBancaria conta) {
        final String sql = "UPDATE conta_bancaria SET agencia_id = ?, titular_1 = ?, titular_2 = ?, data_abertura = ?, saldo = ?, senha = ?, bandeira_cartao = ?, numero_cartao = ?, validade_cartao = ?, cvv = ?, situacao = ? WHERE id = ?";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, conta.getAgenciaId());
            stmt.setLong(2, conta.getTitular1Id());

            if (conta.getTitular2Id() != null) {
                stmt.setLong(3, conta.getTitular2Id());
            } else {
                stmt.setNull(3, Types.BIGINT);
            }

            stmt.setDate(4, conta.getDataAbertura());
            stmt.setBigDecimal(5, conta.getSaldo());
            stmt.setString(6, conta.getSenha());

            if (conta.getBandeiraCartao() != null) {
                stmt.setString(7, conta.getBandeiraCartao());
            } else {
                stmt.setNull(7, Types.VARCHAR);
            }

            if (conta.getNumeroCartao() != null) {
                stmt.setString(8, conta.getNumeroCartao());
            } else {
                stmt.setNull(8, Types.VARCHAR);
            }

            if (conta.getValidadeCartao() != null) {
                stmt.setDate(9, conta.getValidadeCartao());
            } else {
                stmt.setNull(9, Types.DATE);
            }

            if (conta.getCvv() != null) {
                stmt.setString(10, conta.getCvv());
            } else {
                stmt.setNull(10, Types.CHAR);
            }

            // Validação segura do campo ENUM 'situacao'
            String situacao = conta.getSituacao();
            if (situacao == null || situacao.trim().isEmpty()) {
                situacao = "Ativa"; // valor padrão
            } else {
                situacao = situacao.trim();
                if (!situacao.equals("Ativa") && !situacao.equals("Bloqueada") && !situacao.equals("Encerrada")) {
                    throw new IllegalArgumentException("Valor inválido para a situação da conta: " + situacao);
                }
            }
            stmt.setString(11, situacao);

            stmt.setLong(12, conta.getId());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar conta bancária: " + e.getMessage(), e);
        }
    }

    @Override
    public ContaBancaria Find(Long id) {
        final String sql = "SELECT * FROM conta_bancaria WHERE id = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return instanciarConta(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar conta por ID: " + e.getMessage(), e);
        }
        return null;
    }

    @Override
    public List<ContaBancaria> FindAll() {
        final String sql = "SELECT * FROM conta_bancaria ORDER BY id";
        List<ContaBancaria> lista = new ArrayList<>();
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lista.add(instanciarConta(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar todas as contas: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public void Delete(Long id) {
        final String sql = "DELETE FROM conta_bancaria WHERE id = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar conta: " + e.getMessage(), e);
        }
    }
    
    private ContaBancaria instanciarConta(ResultSet rs) throws SQLException {
        ContaBancaria conta = new ContaBancaria();
        conta.setId(rs.getLong("id"));
        conta.setAgenciaId(rs.getLong("agencia_id"));
        conta.setTitular1Id(rs.getLong("titular_1"));
        conta.setTitular2Id((Long) rs.getObject("titular_2"));
        conta.setDataAbertura(rs.getDate("data_abertura"));
        conta.setSaldo(rs.getBigDecimal("saldo"));
        conta.setSenha(rs.getString("senha"));
        conta.setBandeiraCartao(rs.getString("bandeira_cartao"));
        conta.setNumeroCartao(rs.getString("numero_cartao"));
        conta.setValidadeCartao(rs.getDate("validade_cartao"));
        conta.setCvv(rs.getString("cvv"));
        conta.setSituacao(rs.getString("situacao"));
        return conta;
    }
}