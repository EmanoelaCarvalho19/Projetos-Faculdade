package Modelos;

public class ContaCorrente {
	
	private Long id;
	private double saldo;
	private String numeroConta;
	private Agencia agencia;

	public ContaCorrente(Long id, double saldo, String numeroConta, Agencia agencia) {
		this.id = id;
		this.saldo = saldo;
		this.numeroConta = numeroConta;
		this.agencia = agencia;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public String getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	public Agencia getAgencia() {
		return agencia;
	}

	public void setAgencia(Agencia agencia) {
		this.agencia = agencia;
	}
}
