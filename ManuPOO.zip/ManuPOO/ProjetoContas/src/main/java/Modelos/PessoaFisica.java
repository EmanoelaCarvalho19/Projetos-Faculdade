package Modelos;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.Objects;


public class PessoaFisica {

    private Long idPessoa;
    private String cpf;
    private String nomeRegistro;
    private String nomeSocial;
    private Date dataNascimento;
    private String sexo;
    private BigDecimal rendaMensal;

    public PessoaFisica() {
    }

    // --- Getters e Setters ---
    public Long getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(Long idPessoa) {
        this.idPessoa = idPessoa;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNomeRegistro() {
        return nomeRegistro;
    }

    public void setNomeRegistro(String nomeRegistro) {
        this.nomeRegistro = nomeRegistro;
    }

    public String getNomeSocial() {
        return nomeSocial;
    }

    public void setNomeSocial(String nomeSocial) {
        this.nomeSocial = nomeSocial;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public BigDecimal getRendaMensal() {
        return rendaMensal;
    }

    public void setRendaMensal(BigDecimal rendaMensal) {
        this.rendaMensal = rendaMensal;
    }

    // --- toString, equals, hashCode ---
    @Override
    public String toString() {
        return "PessoaFisica{" +
                "idPessoa=" + idPessoa +
                ", cpf='" + cpf + '\'' +
                ", nomeRegistro='" + nomeRegistro + '\'' +
                ", nomeSocial='" + nomeSocial + '\'' +
                ", dataNascimento=" + dataNascimento +
                ", sexo='" + sexo + '\'' +
                ", rendaMensal=" + rendaMensal +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PessoaFisica that = (PessoaFisica) o;
        return Objects.equals(idPessoa, that.idPessoa);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPessoa);
    }
}