package Controller;

import Modelos.PessoaJuridica;
import Interfaces.IPessoaJuridicaDAO;
import Conects.MySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PessoaJuridicaController implements IPessoaJuridicaDAO {

    @Override
    public PessoaJuridica Save(PessoaJuridica pj) {
        if (this.Find(pj.getIdPessoa()) != null) {
            this.Update(pj);
        } else {
            this.Insert(pj);
        }
        return pj;
    }

    @Override
    public PessoaJuridica Insert(PessoaJuridica pj) {
        final String sql = "INSERT INTO pessoa_juridica (id_pessoa, cnpj, razao_social, nome_fantasia, data_abertura, quadro_societario, capital_social) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, pj.getIdPessoa());
            stmt.setString(2, pj.getCnpj());
            stmt.setString(3, pj.getRazaoSocial());
            stmt.setString(4, pj.getNomeFantasia());
            stmt.setDate(5, pj.getDataAbertura());
            stmt.setString(6, pj.getQuadroSocietario());
            stmt.setBigDecimal(7, pj.getCapitalSocial());

            stmt.executeUpdate();
            return pj;

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir pessoa jurídica: " + e.getMessage(), e);
        }
    }

    @Override
    public void Update(PessoaJuridica pj) {
        final String sql = "UPDATE pessoa_juridica SET cnpj = ?, razao_social = ?, nome_fantasia = ?, data_abertura = ?, quadro_societario = ?, capital_social = ? WHERE id_pessoa = ?";

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, pj.getCnpj());
            stmt.setString(2, pj.getRazaoSocial());
            stmt.setString(3, pj.getNomeFantasia());
            stmt.setDate(4, pj.getDataAbertura());
            stmt.setString(5, pj.getQuadroSocietario());
            stmt.setBigDecimal(6, pj.getCapitalSocial());
            stmt.setLong(7, pj.getIdPessoa());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar pessoa jurídica: " + e.getMessage(), e);
        }
    }

    @Override
    public PessoaJuridica Find(Long idPessoa) {
        final String sql = "SELECT * FROM pessoa_juridica WHERE id_pessoa = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, idPessoa);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return instanciarPessoaJuridica(rs);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar pessoa jurídica por ID: " + e.getMessage(), e);
        }
        return null;
    }

    @Override
    public List<PessoaJuridica> FindAll() {
        final String sql = "SELECT * FROM pessoa_juridica ORDER BY id_pessoa";
        List<PessoaJuridica> lista = new ArrayList<>();

        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lista.add(instanciarPessoaJuridica(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar todas as pessoas jurídicas: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public void Delete(Long idPessoa) {
        final String sql = "DELETE FROM pessoa_juridica WHERE id_pessoa = ?";
        try (Connection conn = MySQL.Conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, idPessoa);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar pessoa jurídica: " + e.getMessage(), e);
        }
    }

    private PessoaJuridica instanciarPessoaJuridica(ResultSet rs) throws SQLException {
        PessoaJuridica pj = new PessoaJuridica();
        pj.setIdPessoa(rs.getLong("id_pessoa"));
        pj.setCnpj(rs.getString("cnpj"));
        pj.setRazaoSocial(rs.getString("razao_social"));
        pj.setNomeFantasia(rs.getString("nome_fantasia"));
        pj.setDataAbertura(rs.getDate("data_abertura"));
        pj.setQuadroSocietario(rs.getString("quadro_societario"));
        pj.setCapitalSocial(rs.getBigDecimal("capital_social"));
        return pj;
    }
}