package br.com.unisenai.ProjetoContas;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import Controller.EnderecamentoController;
import Modelos.Enderecamento;

public class EnderecamentoTest {

	private static final EnderecamentoController dao = new EnderecamentoController();
	private static final Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		int opcao = -1;

		while (opcao != 0) {
			exibirMenu();
			try {
				opcao = scanner.nextInt();
				scanner.nextLine();

				switch (opcao) {
				case 1:
					listarTodos();
					break;
				case 2:
					buscarPorId();
					break;
				case 3:
					inserirNovo();
					break;
				case 4:
					atualizarExistente();
					break;
				case 5:
					deletar();
					break;
				case 0:
					System.out.println("\n👋 Encerrando o sistema. Até logo!");
					break;
				default:
					System.out.println("\n❌ Opção inválida! Por favor, tente novamente.");
					break;
				}
			} catch (InputMismatchException e) {
				System.out.println("\n❌ Erro de entrada! Por favor, digite apenas números para as opções.");
				scanner.nextLine(); // Limpa o buffer do scanner para evitar loop infinito
				opcao = -1; // Reseta a opção para continuar no loop
			}

			// Pausa para o usuário poder ler a saída antes de o menu ser exibido novamente
			if (opcao != 0) {
				pressioneEnterParaContinuar();
			}
		}
		scanner.close(); // Fecha o scanner ao sair do programa
	}

	private static void exibirMenu() {
		System.out.println("\n--- 🏦 MENU DE GERENCIAMENTO DE ENDEREÇOS ---");
		System.out.println("1. Listar todos os endereços");
		System.out.println("2. Buscar endereço por ID");
		System.out.println("3. Inserir novo endereço");
		System.out.println("4. Atualizar endereço existente");
		System.out.println("5. Deletar endereço");
		System.out.println("---------------------------------------------");
		System.out.println("0. Sair");
		System.out.print("➡️  Escolha uma opção: ");
	}

	private static void listarTodos() {
		System.out.println("\n--- LISTA DE TODOS OS ENDEREÇOS ---");
		List<Enderecamento> enderecos = dao.FindAll();
		if (enderecos.isEmpty()) {
			System.out.println("ℹ️ Nenhum endereço cadastrado no momento.");
		} else {
			// Itera sobre a lista e imprime cada endereço usando o método toString()
			for (Enderecamento end : enderecos) {
				System.out.println(end);
			}
		}
	}

	private static void buscarPorId() {
		System.out.println("\n--- BUSCAR ENDEREÇO POR ID ---");
		System.out.print("Digite o ID do endereço que deseja buscar: ");
		try {
			Long id = scanner.nextLong();
			scanner.nextLine(); // Limpa o buffer

			Enderecamento endereco = dao.Find(id);

			if (endereco != null) {
				System.out.println("✅ Endereço encontrado:");
				System.out.println(endereco);
			} else {
				System.out.println("❌ Endereço com ID " + id + " não encontrado.");
			}
		} catch (InputMismatchException e) {
			System.out.println("❌ ID inválido. Por favor, digite um número.");
			scanner.nextLine(); // Limpa o buffer
		}
	}

	private static void inserirNovo() {
		System.out.println("\n--- INSERIR NOVO ENDEREÇO ---");
		Enderecamento novoEndereco = new Enderecamento();

		System.out.print("CEP (8 dígitos, sem traço): ");
		novoEndereco.setCep(scanner.nextLine());

		System.out.print("Estado (sigla com 2 letras, ex: SC): ");
		novoEndereco.setSiglaEstado(scanner.nextLine().toUpperCase());

		System.out.print("Município: ");
		novoEndereco.setNomeMunicipio(scanner.nextLine());

		System.out.print("Bairro: ");
		novoEndereco.setNomeBairro(scanner.nextLine());

		System.out.print("Logradouro (Rua/Avenida): ");
		novoEndereco.setNomeLogradouro(scanner.nextLine());

		Enderecamento enderecoSalvo = dao.Save(novoEndereco);
		System.out.println("\n✅ Endereço inserido com sucesso!");
		System.out.println("   ID Gerado: " + enderecoSalvo.getId());
	}

	private static void atualizarExistente() {
		System.out.println("\n--- ATUALIZAR ENDEREÇO ---");
		System.out.print("Digite o ID do endereço que deseja atualizar: ");
		try {
			Long id = scanner.nextLong();
			scanner.nextLine(); // Limpa o buffer

			Enderecamento enderecoParaAtualizar = dao.Find(id);
			if (enderecoParaAtualizar == null) {
				System.out.println("❌ Endereço com ID " + id + " não encontrado.");
				return; // Volta para o menu
			}

			System.out.println("\n📝 Editando o endereço (deixe em branco para não alterar):");

			System.out.print("Novo CEP (" + enderecoParaAtualizar.getCep() + "): ");
			String cep = scanner.nextLine();
			if (!cep.trim().isEmpty()) {
				enderecoParaAtualizar.setCep(cep);
			}

			System.out.print("Novo Estado (" + enderecoParaAtualizar.getSiglaEstado() + "): ");
			String estado = scanner.nextLine();
			if (!estado.trim().isEmpty()) {
				enderecoParaAtualizar.setSiglaEstado(estado.toUpperCase());
			}

			System.out.print("Novo Município (" + enderecoParaAtualizar.getNomeMunicipio() + "): ");
			String municipio = scanner.nextLine();
			if (!municipio.trim().isEmpty()) {
				enderecoParaAtualizar.setNomeMunicipio(municipio);
			}

			System.out.print("Novo Bairro (" + enderecoParaAtualizar.getNomeBairro() + "): ");
			String bairro = scanner.nextLine();
			if (!bairro.trim().isEmpty()) {
				enderecoParaAtualizar.setNomeBairro(bairro);
			}

			System.out.print("Novo Logradouro (" + enderecoParaAtualizar.getNomeLogradouro() + "): ");
			String logradouro = scanner.nextLine();
			if (!logradouro.trim().isEmpty()) {
				enderecoParaAtualizar.setNomeLogradouro(logradouro);
			}

			dao.Save(enderecoParaAtualizar); // O Save chama o Update, pois o objeto já tem ID
			System.out.println("\n✅ Endereço atualizado com sucesso!");

		} catch (InputMismatchException e) {
			System.out.println("❌ ID inválido. Por favor, digite um número.");
			scanner.nextLine(); // Limpa o buffer
		}
	}

	private static void deletar() {
		System.out.println("\n--- DELETAR ENDEREÇO ---");
		System.out.print("Digite o ID do endereço que deseja deletar: ");
		try {
			Long id = scanner.nextLong();
			scanner.nextLine(); // Limpa o buffer

			// É uma boa prática confirmar antes de uma operação destrutiva
			Enderecamento endereco = dao.Find(id);
			if (endereco == null) {
				System.out.println("❌ Endereço com ID " + id + " não encontrado.");
				return;
			}

			System.out.println("Você tem certeza que deseja deletar o seguinte endereço?");
			System.out.println(endereco);
			System.out.print("Digite 'S' para confirmar ou qualquer outra tecla para cancelar: ");
			String confirmacao = scanner.nextLine();

			if (confirmacao.equalsIgnoreCase("S")) {
				dao.Delete(id);
				System.out.println("✅ Endereço deletado com sucesso.");
			} else {
				System.out.println("ℹ️ Operação de deleção cancelada.");
			}

		} catch (InputMismatchException e) {
			System.out.println("❌ ID inválido. Por favor, digite um número.");
			scanner.nextLine(); // Limpa o buffer
		}
	}

	private static void pressioneEnterParaContinuar() {
		System.out.print("\nPressione [Enter] para continuar...");
		scanner.nextLine();
	}
}