package Interfaces;

import Modelos.Agencia;
import java.util.List;


public interface IAgenciaDAO {

    Agencia Save(Agencia agencia);
    Agencia Insert(Agencia agencia);
    void Update(Agencia agencia);
    Agencia Find(Long id);
    List<Agencia> FindAll();
    void Delete(Long id);
}
