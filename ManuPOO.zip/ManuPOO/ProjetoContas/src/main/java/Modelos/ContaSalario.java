package Modelos;

public class ContaSalario {

	private Long id;
	private String cnpjEmpresa;
	private double limiteAdiantamentoConsignado;
	private String contaPortabilidade;

	public ContaSalario(Long id, String cnpjEmpresa, double limiteAdiantamentoConsignado, String contaPortabilidade) {
		this.id = id;
		this.cnpjEmpresa = cnpjEmpresa;
		this.limiteAdiantamentoConsignado = limiteAdiantamentoConsignado;
		this.contaPortabilidade = contaPortabilidade;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCnpjEmpresa() {
		return cnpjEmpresa;
	}

	public void setCnpjEmpresa(String cnpjEmpresa) {
		this.cnpjEmpresa = cnpjEmpresa;
	}

	public double getLimiteAdiantamentoConsignado() {
		return limiteAdiantamentoConsignado;
	}

	public void setLimiteAdiantamentoConsignado(double limiteAdiantamentoConsignado) {
		this.limiteAdiantamentoConsignado = limiteAdiantamentoConsignado;
	}

	public String getContaPortabilidade() {
		return contaPortabilidade;
	}

	public void setContaPortabilidade(String contaPortabilidade) {
		this.contaPortabilidade = contaPortabilidade;
	}
}
