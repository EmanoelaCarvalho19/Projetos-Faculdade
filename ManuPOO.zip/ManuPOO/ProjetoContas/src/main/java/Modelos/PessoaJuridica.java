package Modelos;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.Objects;

/**
 * Representa os dados específicos de uma Pessoa Jurídica,
 * que complementam uma entrada na tabela Pessoa.
 */
public class PessoaJuridica {

    private Long idPessoa; // Chave primária e estrangeira
    private String cnpj;
    private String razaoSocial;
    private String nomeFantasia;
    private Date dataAbertura;
    private String quadroSocietario;
    private BigDecimal capitalSocial; // BigDecimal é ideal para valores monetários

    public PessoaJuridica() {
    }

    // --- Getters e Setters ---
    public Long getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(Long idPessoa) {
        this.idPessoa = idPessoa;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public Date getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(Date dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public String getQuadroSocietario() {
        return quadroSocietario;
    }

    public void setQuadroSocietario(String quadroSocietario) {
        this.quadroSocietario = quadroSocietario;
    }

    public BigDecimal getCapitalSocial() {
        return capitalSocial;
    }

    public void setCapitalSocial(BigDecimal capitalSocial) {
        this.capitalSocial = capitalSocial;
    }

    // --- toString, equals, hashCode ---
    @Override
    public String toString() {
        return "PessoaJuridica{" +
                "idPessoa=" + idPessoa +
                ", cnpj='" + cnpj + '\'' +
                ", razaoSocial='" + razaoSocial + '\'' +
                ", nomeFantasia='" + nomeFantasia + '\'' +
                ", dataAbertura=" + dataAbertura +
                ", capitalSocial=" + capitalSocial +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PessoaJuridica that = (PessoaJuridica) o;
        return Objects.equals(idPessoa, that.idPessoa);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPessoa);
    }
}