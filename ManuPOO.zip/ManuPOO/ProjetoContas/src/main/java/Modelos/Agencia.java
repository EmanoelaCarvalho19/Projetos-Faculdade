package Modelos;

import java.util.Objects;


public class Agencia {

    private Long id;
    private Long bancoId; 
    private Long idEnderecamento; 
    private String nome;
    private String telefone;
    private String situacao;

    public Agencia() {
    }

    // --- Getters e Setters ---
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBancoId() {
        return bancoId;
    }

    public void setBancoId(Long bancoId) {
        this.bancoId = bancoId;
    }

    public Long getIdEnderecamento() {
        return idEnderecamento;
    }

    public void setIdEnderecamento(Long idEnderecamento) {
        this.idEnderecamento = idEnderecamento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    @Override
    public String toString() {
        return "Agencia{" +
                "id=" + id +
                ", bancoId=" + bancoId +
                ", idEnderecamento=" + idEnderecamento +
                ", nome='" + nome + '\'' +
                ", telefone='" + telefone + '\'' +
                ", situacao='" + situacao + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Agencia agencia = (Agencia) o;
        return Objects.equals(id, agencia.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}