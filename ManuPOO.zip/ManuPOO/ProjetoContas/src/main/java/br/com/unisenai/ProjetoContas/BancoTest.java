package br.com.unisenai.ProjetoContas;

import Controller.BancoController;
import Modelos.Banco;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class BancoTest {

    private static final BancoController dao = new BancoController();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;

        while (opcao != 0) {
            exibirMenu();
            try {
                opcao = scanner.nextInt();
                scanner.nextLine(); // Limpa o buffer

                switch (opcao) {
                    case 1:
                        listarTodos();
                        break;
                    case 2:
                        inserirNovo();
                        break;
                    case 3:
                        deletar();
                        break;
                    case 0:
                        System.out.println("\n👋 Encerrando o sistema. Até logo!");
                        break;
                    default:
                        System.out.println("\n❌ Opção inválida! Por favor, tente novamente.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("\n❌ Erro de entrada! Por favor, digite apenas números.");
                scanner.nextLine();
                opcao = -1;
            }
            if (opcao != 0) {
                pressioneEnterParaContinuar();
            }
        }
        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("\n--- 🏛️ MENU DE GERENCIAMENTO DE BANCOS ---");
        System.out.println("1. Listar todos os bancos");
        System.out.println("2. Inserir novo banco");
        System.out.println("3. Deletar banco");
        System.out.println("-----------------------------------------");
        System.out.println("0. Sair");
        System.out.print("➡️  Escolha uma opção: ");
    }

    private static void listarTodos() {
        System.out.println("\n--- LISTA DE TODOS OS BANCOS ---");
        List<Banco> bancos = dao.FindAll();
        if (bancos.isEmpty()) {
            System.out.println("ℹ️ Nenhum banco cadastrado no momento.");
        } else {
            // Itera sobre a lista e imprime cada banco usando o método toString()
            for (Banco banco : bancos) {
                System.out.println(banco);
            }
        }
    }

    private static void inserirNovo() {
        System.out.println("\n--- INSERIR NOVO BANCO ---");
        Banco novoBanco = new Banco();

        try {
            System.out.print("Código FEBRABAN (3 dígitos, ex: 001 para Banco do Brasil): ");
            novoBanco.setCodigoFebraban(scanner.nextLine());
            
            System.out.print("Nome do Banco (ex: Caixa Econômica Federal): ");
            novoBanco.setNome(scanner.nextLine());

            System.out.print("Máscara da Conta (opcional, ex: #####-#): ");
            novoBanco.setMascaraConta(scanner.nextLine());
            
            Banco bancoSalvo = dao.Save(novoBanco);
            System.out.println("\n✅ Banco inserido com sucesso!\n" + bancoSalvo);

        } catch (Exception e) {
            System.out.println("❌ Ocorreu um erro inesperado: " + e.getMessage());
        }
    }

    private static void deletar() {
         System.out.print("\nDigite o ID do banco que deseja deletar: ");
        try {
            Long id = scanner.nextLong();
            scanner.nextLine();
            
            Banco banco = dao.Find(id);
            if (banco == null) {
                System.out.println("❌ Banco com ID " + id + " não encontrado.");
                return;
            }

            System.out.println("Você tem certeza que deseja deletar o banco '" + banco.getNome() + "'?");
            System.out.print("Esta ação pode ser bloqueada se houver agências associadas. Digite 'S' para confirmar: ");
            String confirmacao = scanner.nextLine();
            
            if (confirmacao.equalsIgnoreCase("S")) {
                dao.Delete(id);
                System.out.println("✅ Comando de deleção executado.");
            } else {
                System.out.println("ℹ️ Operação cancelada.");
            }
        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido.");
            scanner.nextLine();
        } catch (RuntimeException e) {
            System.out.println("❌ ERRO: Não foi possível deletar. " + e.getMessage());
        }
    }
    
    private static void pressioneEnterParaContinuar() {
        System.out.print("\nPressione [Enter] para continuar...");
        scanner.nextLine();
    }
}
