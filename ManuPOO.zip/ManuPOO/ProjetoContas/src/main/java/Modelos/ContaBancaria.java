package Modelos;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.Objects;

public class ContaBancaria {

    private Long id;
    private Long agenciaId;
    private Long titular1Id;
    private Long titular2Id;
    private Date dataAbertura;
    private BigDecimal saldo;
    private String senha;
    private String bandeiraCartao;
    private String numeroCartao;
    private Date validadeCartao;
    private String cvv;
    private String situacao;

    public ContaBancaria() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAgenciaId() {
        return agenciaId;
    }

    public void setAgenciaId(Long agenciaId) {
        this.agenciaId = agenciaId;
    }

    public Long getTitular1Id() {
        return titular1Id;
    }

    public void setTitular1Id(Long titular1Id) {
        this.titular1Id = titular1Id;
    }

    public Long getTitular2Id() {
        return titular2Id;
    }

    public void setTitular2Id(Long titular2Id) {
        this.titular2Id = titular2Id;
    }

    public Date getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(Date dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public BigDecimal getSaldo() {
        return saldo;
    }

    public void setSaldo(BigDecimal saldo) {
        this.saldo = saldo;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getBandeiraCartao() {
        return bandeiraCartao;
    }

    public void setBandeiraCartao(String bandeiraCartao) {
        this.bandeiraCartao = bandeiraCartao;
    }

    public String getNumeroCartao() {
        return numeroCartao;
    }

    public void setNumeroCartao(String numeroCartao) {
        this.numeroCartao = numeroCartao;
    }

    public Date getValidadeCartao() {
        return validadeCartao;
    }

    public void setValidadeCartao(Date validadeCartao) {
        this.validadeCartao = validadeCartao;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    // --- toString, equals, hashCode ---
    @Override
    public String toString() {
        return "ContaBancaria{" +
                "id=" + id +
                ", agenciaId=" + agenciaId +
                ", titular1Id=" + titular1Id +
                ", titular2Id=" + titular2Id +
                ", dataAbertura=" + dataAbertura +
                ", saldo=" + saldo +
                ", situacao='" + situacao + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ContaBancaria that = (ContaBancaria) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}