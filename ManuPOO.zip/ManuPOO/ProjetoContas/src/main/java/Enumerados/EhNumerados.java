package Enumerados;

public class EhNumerados {
    public static void main(String[] args) {
        int Sexo = 5;
        if (Sexo == 8 ) {
            System.out.println("???");
        }
    }
}