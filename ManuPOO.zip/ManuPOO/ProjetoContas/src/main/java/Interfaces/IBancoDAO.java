package Interfaces;

import Modelos.Banco;
import java.util.List;

public interface IBancoDAO {

    Banco Save(Banco banco);
    Banco Insert(Banco banco);
    void Update(Banco banco);
    Banco Find(Long id);
    List<Banco> FindAll();
    void Delete(Long id);
}
