package br.com.unisenai.ProjetoContas;

import Controller.PessoaController;
import Controller.PessoaFisicaController;
import Modelos.Pessoa;
import Modelos.PessoaFisica;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class PessoaFisicaTest {

    // Precisamos dos dois controllers agora!
    private static final PessoaController pessoaDAO = new PessoaController();
    private static final PessoaFisicaController pessoaFisicaDAO = new PessoaFisicaController();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;

        while (opcao != 0) {
            exibirMenu();
            try {
                opcao = scanner.nextInt();
                scanner.nextLine();

                switch (opcao) {
                    case 1:
                        listarTodos();
                        break;
                    case 2:
                        inserirNovo();
                        break;
                    case 3:
                        deletar();
                        break;
                    case 0:
                        System.out.println("\n👋 Encerrando o sistema. Até logo!");
                        break;
                    default:
                        System.out.println("\n❌ Opção inválida! Por favor, tente novamente.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("\n❌ Erro de entrada! Por favor, digite apenas números.");
                scanner.nextLine();
                opcao = -1;
            }
            if (opcao != 0) {
                pressioneEnterParaContinuar();
            }
        }
        scanner.close();
    }
    
    private static void exibirMenu() {
        System.out.println("\n--- 🧑 MENU DE GERENCIAMENTO DE PESSOAS FÍSICAS ---");
        System.out.println("1. Listar todas as pessoas físicas (com detalhes)");
        System.out.println("2. Inserir nova pessoa física");
        System.out.println("3. Deletar pessoa física (e a pessoa associada)");
        System.out.println("-------------------------------------------------");
        System.out.println("0. Sair");
        System.out.print("➡️  Escolha uma opção: ");
    }

    private static void listarTodos() {
        System.out.println("\n--- LISTA DE TODAS AS PESSOAS FÍSICAS ---");
        List<PessoaFisica> pessoasFisicas = pessoaFisicaDAO.FindAll();

        if (pessoasFisicas.isEmpty()) {
            System.out.println("ℹ️ Nenhuma pessoa física cadastrada no momento.");
        } else {
            for (PessoaFisica pf : pessoasFisicas) {
                // Para cada PessoaFisica, buscamos a Pessoa correspondente para exibir dados completos
                Pessoa p = pessoaDAO.Find(pf.getIdPessoa());
                System.out.println("\n-------------------------------------------");
                System.out.println("ID Pessoa: " + pf.getIdPessoa());
                System.out.println("Nome: " + pf.getNomeRegistro());
                System.out.println("CPF: " + pf.getCpf());
                System.out.println("Data de Nascimento: " + pf.getDataNascimento());
                if(p != null) {
                    System.out.println("Cliente Desde: " + p.getClienteDesde());
                    System.out.println("Telefone: " + p.getTelefone());
                    System.out.println("ID Endereço: " + p.getIdEnderecamento());
                }
                System.out.println("-------------------------------------------");
            }
        }
    }
    
    private static void inserirNovo() {
        System.out.println("\n--- INSERIR NOVA PESSOA FÍSICA ---");
        System.out.println("O cadastro é feito em 2 etapas: 1. Pessoa | 2. Detalhes Físicos");

        Pessoa novaPessoa = new Pessoa();
        PessoaFisica novaPessoaFisica = new PessoaFisica();
        
        try {
            // --- ETAPA 1: DADOS DA 'PESSOA' ---
            System.out.println("\n--- ETAPA 1: DADOS GERAIS DA PESSOA ---");
            System.out.print("ID do Endereçamento (deve existir): ");
            novaPessoa.setIdEnderecamento(scanner.nextLong());
            scanner.nextLine();
            
            System.out.print("Número do endereço: ");
            novaPessoa.setNumeroEndereco(scanner.nextLine());
            
            System.out.print("Telefone: ");
            novaPessoa.setTelefone(scanner.nextLine());
            
            System.out.print("Data de início como cliente (AAAA-MM-DD): ");
            novaPessoa.setClienteDesde(converterStringParaSqlDate(scanner.nextLine()));
            novaPessoa.setSituacao("Ativo");

            // SALVA A PESSOA PRIMEIRO PARA OBTER O ID
            Pessoa pessoaSalva = pessoaDAO.Save(novaPessoa);
            if(pessoaSalva == null || pessoaSalva.getId() == null) {
                System.out.println("❌ Erro ao salvar os dados gerais da pessoa. A operação foi cancelada.");
                return;
            }
            System.out.println("✅ Etapa 1 concluída! ID de Pessoa gerado: " + pessoaSalva.getId());

            // --- ETAPA 2: DADOS DA 'PESSOA FÍSICA' ---
            System.out.println("\n--- ETAPA 2: DADOS ESPECÍFICOS DA PESSOA FÍSICA ---");
            novaPessoaFisica.setIdPessoa(pessoaSalva.getId()); // Usa o ID gerado!
            
            System.out.print("CPF (sem pontos ou traços): ");
            novaPessoaFisica.setCpf(scanner.nextLine());
            
            System.out.print("Nome de Registro (completo): ");
            novaPessoaFisica.setNomeRegistro(scanner.nextLine());

            System.out.print("Data de Nascimento (AAAA-MM-DD): ");
            novaPessoaFisica.setDataNascimento(converterStringParaSqlDate(scanner.nextLine()));
            
            System.out.print("Renda Mensal (ex: 3500.50): ");
            novaPessoaFisica.setRendaMensal(scanner.nextBigDecimal());
            scanner.nextLine();
            
            // SALVA OS DADOS ESPECÍFICOS
            pessoaFisicaDAO.Save(novaPessoaFisica);
            System.out.println("\n✅ Etapa 2 concluída! Pessoa Física cadastrada com sucesso!");

        } catch (InputMismatchException e) {
            System.out.println("❌ Entrada inválida. A operação foi cancelada.");
            scanner.nextLine();
        } catch (ParseException e) {
            System.out.println("❌ Formato de data inválido! Use AAAA-MM-DD. A operação foi cancelada.");
        } catch (Exception e) {
            System.out.println("❌ Ocorreu um erro inesperado: " + e.getMessage());
        }
    }
    
    private static void deletar() {
         System.out.print("\nDigite o ID da Pessoa que deseja deletar (isso deletará a Pessoa e a Pessoa Física associada): ");
        try {
            Long id = scanner.nextLong();
            scanner.nextLine();
            
            PessoaFisica pf = pessoaFisicaDAO.Find(id);
            if (pf == null) {
                System.out.println("❌ Pessoa Física com ID " + id + " não encontrada.");
                return;
            }

            System.out.println("Você tem certeza que deseja deletar " + pf.getNomeRegistro() + " (CPF: " + pf.getCpf() + ")?");
            System.out.print("Esta ação é irreversível. Digite 'S' para confirmar: ");
            String confirmacao = scanner.nextLine();
            
            if (confirmacao.equalsIgnoreCase("S")) {
                // A mágica acontece aqui: deletamos a 'Pessoa'.
                // O 'ON DELETE CASCADE' no banco de dados se encarrega de deletar a 'PessoaFisica'.
                pessoaDAO.Delete(id);
                System.out.println("✅ Pessoa deletada com sucesso.");
            } else {
                System.out.println("ℹ️ Operação cancelada.");
            }
        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido.");
            scanner.nextLine();
        }
    }
    
    private static Date converterStringParaSqlDate(String dataStr) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date parsed = format.parse(dataStr);
        return new java.sql.Date(parsed.getTime());
    }

    private static void pressioneEnterParaContinuar() {
        System.out.print("\nPressione [Enter] para continuar...");
        scanner.nextLine();
    }
}
