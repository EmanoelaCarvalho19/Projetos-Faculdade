package Interfaces;

import Modelos.ContaBancaria;
import java.util.List;

public interface IContaBancariaDAO {

    ContaBancaria Save(ContaBancaria conta);
    ContaBancaria Insert(ContaBancaria conta);
    void Update(ContaBancaria conta);
    ContaBancaria Find(Long id);
    List<ContaBancaria> FindAll();
    void Delete(Long id);
}
