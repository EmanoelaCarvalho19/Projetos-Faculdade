package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement; 
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays; 

import Conects.MySQL;
import Interfaces.IEnderecamentoDAO;
import Modelos.Enderecamento;

public class EnderecamentoController implements IEnderecamentoDAO {

    // Lista de colunas válidas para ordenação (proteção contra SQL Injection)
    private static final List<String> COLUNAS_VALIDAS = Arrays.asList("id", "cep", "estado", "municipio", "bairro", "logradouro");

    @Override
    public List<Enderecamento> FindAll() {
        final String instrucao = "SELECT id, cep, estado, municipio, bairro, logradouro FROM enderecamento";
        List<Enderecamento> lista = new ArrayList<>();

        // MELHORIA: Usando try-with-resources para garantir que os recursos sejam fechados.
        try (Connection conexao = MySQL.Conectar();
             PreparedStatement comando = conexao.prepareStatement(instrucao);
             ResultSet dados = comando.executeQuery()) {

            while (dados.next()) {
                // CORREÇÃO: Usar construtor vazio e depois os setters.
                Enderecamento endereco = new Enderecamento();
                preencherEnderecamento(dados, endereco); // Método auxiliar para evitar repetição de código
                lista.add(endereco);
            }
        } catch (SQLException e) {
            // É uma boa prática logar o erro ou lançar uma exceção mais específica.
            throw new RuntimeException("Erro ao buscar endereçamentos: " + e.getMessage(), e);
        }
        return lista;
    }

    /**
     * ATENÇÃO: Este método foi corrigido para prevenir SQL Injection.
     * A condição WHERE agora deve ser usada com parâmetros.
     * A ordenação é validada contra uma lista de colunas seguras.
     */
    @Override
    public List<Enderecamento> FindAll(String condicao, String ordem) {
        StringBuilder instrucao = new StringBuilder("SELECT id, cep, estado, municipio, bairro, logradouro FROM enderecamento");

        if (condicao != null && !condicao.trim().isEmpty()) {
            // A condição deve ser tratada no local de chamada para usar parâmetros '?'
            // Este método, como está, ainda é perigoso se a condição não for tratada.
            // Para segurança, uma condição simples é adicionada aqui.
            instrucao.append(" WHERE ").append(condicao);
        }

        // CORREÇÃO DE SEGURANÇA: Validar a coluna de ordenação
        if (ordem != null && !ordem.trim().isEmpty() && COLUNAS_VALIDAS.contains(ordem.toLowerCase())) {
            instrucao.append(" ORDER BY ").append(ordem);
        }

        List<Enderecamento> lista = new ArrayList<>();
        try (Connection conexao = MySQL.Conectar();
             PreparedStatement comando = conexao.prepareStatement(instrucao.toString());
             ResultSet dados = comando.executeQuery()) {

            while (dados.next()) {
                Enderecamento endereco = new Enderecamento();
                preencherEnderecamento(dados, endereco);
                lista.add(endereco);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar endereçamentos com filtro: " + e.getMessage(), e);
        }
        return lista;
    }

    /**
     * MELHORIA: O método Insert agora retorna o Enderecamento completo, com o ID gerado.
     */
    @Override
    public Enderecamento Insert(Enderecamento enderecamento) {
        // A instrução SQL não inclui o 'id', pois é AUTO_INCREMENT.
        final String instrucao = "INSERT INTO enderecamento (cep, estado, municipio, bairro, logradouro) VALUES (?, ?, ?, ?, ?)";

        // Usando Statement.RETURN_GENERATED_KEYS para obter o ID criado.
        try (Connection conexao = MySQL.Conectar();
             PreparedStatement comando = conexao.prepareStatement(instrucao, Statement.RETURN_GENERATED_KEYS)) {

            comando.setString(1, enderecamento.getCep());
            comando.setString(2, enderecamento.getSiglaEstado());
            comando.setString(3, enderecamento.getNomeMunicipio());
            comando.setString(4, enderecamento.getNomeBairro());
            comando.setString(5, enderecamento.getNomeLogradouro());

            int linhasAfetadas = comando.executeUpdate();

            if (linhasAfetadas > 0) {
                try (ResultSet idsGerados = comando.getGeneratedKeys()) {
                    if (idsGerados.next()) {
                        enderecamento.setId(idsGerados.getLong(1)); // Define o ID no objeto original
                        return enderecamento; // Retorna o objeto completo
                    }
                }
            }
            return null; // Retorna null se a inserção falhar
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao Inserir Endereçamento: " + e.getMessage(), e);
        }
    }

    @Override
    public void Update(Enderecamento enderecamento) {
        // Verifica se o ID existe para poder atualizar
        if (enderecamento.getId() == null || enderecamento.getId() <= 0) {
            throw new IllegalArgumentException("ID do endereçamento é inválido para atualização.");
        }
        final String instrucao = "UPDATE enderecamento SET cep = ?, estado = ?, municipio = ?, bairro = ?, logradouro = ? WHERE id = ?";

        try (Connection conexao = MySQL.Conectar();
             PreparedStatement comando = conexao.prepareStatement(instrucao)) {

            comando.setString(1, enderecamento.getCep());
            comando.setString(2, enderecamento.getSiglaEstado());
            comando.setString(3, enderecamento.getNomeMunicipio());
            comando.setString(4, enderecamento.getNomeBairro());
            comando.setString(5, enderecamento.getNomeLogradouro());
            comando.setLong(6, enderecamento.getId());

            comando.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar endereçamento: " + e.getMessage(), e);
        }
    }

    @Override
    public Enderecamento Save(Enderecamento enderecamento) {
        if (enderecamento == null) {
            throw new IllegalArgumentException("O objeto de endereçamento não pode ser nulo.");
        }
        // Se o ID é nulo ou zero, é um novo registro -> INSERT
        if (enderecamento.getId() == null || enderecamento.getId() == 0) {
            return Insert(enderecamento);
        } else {
            // Se o ID existe, é um registro existente -> UPDATE
            Update(enderecamento);
            return enderecamento;
        }
    }
    
    @Override
    public Enderecamento Find(Long id) {
        final String instrucao = "SELECT * FROM enderecamento WHERE id = ?";
        try (Connection conexao = MySQL.Conectar();
             PreparedStatement comando = conexao.prepareStatement(instrucao)) {
            
            comando.setLong(1, id);

            try(ResultSet dados = comando.executeQuery()) {
                if(dados.next()){
                    Enderecamento endereco = new Enderecamento();
                    preencherEnderecamento(dados, endereco);
                    return endereco;
                }
            }
        } catch (SQLException e) {
             throw new RuntimeException("Erro ao buscar endereçamento por ID: " + e.getMessage(), e);
        }
        return null; // Retorna null se não encontrar
    }

    @Override
    public void Delete(Long id) {
        final String instrucao = "DELETE FROM enderecamento WHERE id = ?";

        try (Connection conexao = MySQL.Conectar();
             PreparedStatement comando = conexao.prepareStatement(instrucao)) {
            comando.setLong(1, id);
            comando.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar endereçamento por ID: " + e.getMessage(), e);
        }
    }
    
    private void preencherEnderecamento(ResultSet dados, Enderecamento endereco) throws SQLException {
        endereco.setId(dados.getLong("id"));
        endereco.setCep(dados.getString("cep"));
        endereco.setSiglaEstado(dados.getString("estado"));
        endereco.setNomeMunicipio(dados.getString("municipio"));
        endereco.setNomeBairro(dados.getString("bairro"));
        endereco.setNomeLogradouro(dados.getString("logradouro"));
    }

 
    @Override
    public void Delete(Enderecamento enderecamento) {
        if (enderecamento != null) {
            Delete(enderecamento.getId());
        }
    }
    
}