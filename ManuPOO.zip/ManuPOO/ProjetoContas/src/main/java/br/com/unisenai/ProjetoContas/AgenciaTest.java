package br.com.unisenai.ProjetoContas;
import Controller.AgenciaController;
import Modelos.Agencia;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class AgenciaTest {

    private static final AgenciaController dao = new AgenciaController();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;

        while (opcao != 0) {
            exibirMenu();
            try {
                opcao = scanner.nextInt();
                scanner.nextLine(); 

                switch (opcao) {
                    case 1:
                        listarTodos();
                        break;
                    case 2:
                        inserirNovo();
                        break;
                    case 3:
                        deletar();
                        break;
                    case 0:
                        System.out.println("\n👋 Encerrando o sistema. Até logo!");
                        break;
                    default:
                        System.out.println("\n❌ Opção inválida! Por favor, tente novamente.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("\n❌ Erro de entrada! Por favor, digite apenas números.");
                scanner.nextLine();
                opcao = -1;
            }
            if (opcao != 0) {
                pressioneEnterParaContinuar();
            }
        }
        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("\n--- 🏦 MENU DE GERENCIAMENTO DE AGÊNCIAS ---");
        System.out.println("1. Listar todas as agências");
        System.out.println("2. Inserir nova agência");
        System.out.println("3. Deletar agência");
        System.out.println("-------------------------------------------");
        System.out.println("0. Sair");
        System.out.print("➡️  Escolha uma opção: ");
    }

    private static void listarTodos() {
        System.out.println("\n--- LISTA DE TODAS AS AGÊNCIAS ---");
        List<Agencia> agencias = dao.FindAll();
        if (agencias.isEmpty()) {
            System.out.println("ℹ️ Nenhuma agência cadastrada no momento.");
        } else {
            agencias.forEach(System.out::println);
        }
    }

    private static void inserirNovo() {
        System.out.println("\n--- INSERIR NOVA AGÊNCIA ---");
        Agencia novaAgencia = new Agencia();

        try {
            System.out.println("ℹ️ É necessário associar um banco e um endereço existentes.");
            
            System.out.print("ID do Banco: ");
            novaAgencia.setBancoId(scanner.nextLong());
            
            System.out.print("ID do Endereçamento: ");
            novaAgencia.setIdEnderecamento(scanner.nextLong());
            scanner.nextLine(); // Limpa o buffer
            
            System.out.print("Nome da Agência (ex: Agência Centro): ");
            novaAgencia.setNome(scanner.nextLine());
            
            System.out.print("Telefone (opcional): ");
            novaAgencia.setTelefone(scanner.nextLine());

            // A situação pode ser definida como 'Ativo' por padrão
            novaAgencia.setSituacao("Ativo");
            
            Agencia agenciaSalva = dao.Save(novaAgencia);
            System.out.println("\n✅ Agência inserida com sucesso!\n" + agenciaSalva);

        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido. A operação foi cancelada.");
            scanner.nextLine();
        } catch (Exception e) {
            System.out.println("❌ Ocorreu um erro inesperado: " + e.getMessage());
        }
    }

    private static void deletar() {
         System.out.print("\nDigite o ID da agência que deseja deletar: ");
        try {
            Long id = scanner.nextLong();
            scanner.nextLine();
            
            Agencia agencia = dao.Find(id);
            if (agencia == null) {
                System.out.println("❌ Agência com ID " + id + " não encontrada.");
                return;
            }

            System.out.println("Você tem certeza que deseja deletar a agência '" + agencia.getNome() + "'?");
            System.out.print("Esta ação pode ser bloqueada se houver contas associadas. Digite 'S' para confirmar: ");
            String confirmacao = scanner.nextLine();
            
            if (confirmacao.equalsIgnoreCase("S")) {
                dao.Delete(id);
                System.out.println("✅ Comando de deleção executado.");
            } else {
                System.out.println("ℹ️ Operação cancelada.");
            }
        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido.");
            scanner.nextLine();
        } catch (RuntimeException e) {
            System.out.println("❌ ERRO: Não foi possível deletar. " + e.getMessage());
        }
    }
    
    private static void pressioneEnterParaContinuar() {
        System.out.print("\nPressione [Enter] para continuar...");
        scanner.nextLine();
    }
}