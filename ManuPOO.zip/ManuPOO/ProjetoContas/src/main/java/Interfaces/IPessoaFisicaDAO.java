package Interfaces;

import Modelos.PessoaFisica;
import java.util.List;


public interface IPessoaFisicaDAO {

    PessoaFisica Save(PessoaFisica pessoaFisica);

    PessoaFisica Insert(PessoaFisica pessoaFisica);

    void Update(PessoaFisica pessoaFisica);

    PessoaFisica Find(Long idPessoa);

    List<PessoaFisica> FindAll();

    void Delete(Long idPessoa);
}