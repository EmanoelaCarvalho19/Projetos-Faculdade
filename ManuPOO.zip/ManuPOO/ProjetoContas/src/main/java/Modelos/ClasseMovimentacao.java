package Modelos;

import java.util.Date;

public class ClasseMovimentacao {
	
	private Long id;
	private Date dataHora;
	private String numeroConta;
	private String tipoOperacao;
	private double valor;
	private String situacao;

	public ClasseMovimentacao(Long id, Date dataHora, String numeroConta, String tipoOperacao, double valor,
			String situacao) {
		this.id = id;
		this.dataHora = dataHora;
		this.numeroConta = numeroConta;
		this.tipoOperacao = tipoOperacao;
		this.valor = valor;
		this.situacao = situacao;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getDataHora() {
		return dataHora;
	}

	public void setDataHora(Date dataHora) {
		this.dataHora = dataHora;
	}

	public String getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	public String getTipoOperacao() {
		return tipoOperacao;
	}

	public void setTipoOperacao(String tipoOperacao) {
		this.tipoOperacao = tipoOperacao;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
}
