package Interfaces;

import java.util.List;
import Modelos.Enderecamento;


public interface IEnderecamentoDAO {
  
    Enderecamento Save(Enderecamento enderecamento);
    Enderecamento Insert(Enderecamento enderecamento);
    void Update(Enderecamento enderecamento);
    Enderecamento Find(Long id);
    List<Enderecamento> FindAll();
    List<Enderecamento> FindAll(String condicao, String ordem);
    void Delete(Long id);
    void Delete(Enderecamento enderecamento);
}