package Interfaces;

import Modelos.Pessoa;
import java.util.List;


public interface IPessoaDAO {

    Pessoa Save(Pessoa pessoa);

    Pessoa Insert(Pessoa pessoa);

    void Update(Pessoa pessoa);

    Pessoa Find(Long id);

    List<Pessoa> FindAll();

    void Delete(Long id);

    void Delete(Pessoa pessoa);
}