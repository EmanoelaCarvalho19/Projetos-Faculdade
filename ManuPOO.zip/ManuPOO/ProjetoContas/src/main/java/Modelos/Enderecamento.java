package Modelos;

import java.util.Objects;

/**
 * Representa a entidade Enderecamento.
 * Esta é uma classe de modelo (POJO - Plain Old Java Object) com getters, setters,
 * construtores e métodos utilitários como toString, equals e hashCode.
 */
public class Enderecamento {
	
	private Long id;
	private String cep;
	private String siglaEstado;
	private String nomeMunicipio;
	private String nomeBairro;
	private String nomeLogradouro;

	/**
	 * ADIÇÃO: Construtor vazio (sem argumentos).
	 * Essencial para que o DAO e muitos frameworks (como JPA/Hibernate) possam
	 * criar instâncias do objeto para depois preenchê-las com dados.
	 */
	public Enderecamento() {
	}

	/**
	 * Construtor completo (o que você já tinha).
	 * Útil para criar objetos quando você já tem todas as informações.
	 */
	public Enderecamento(Long id, String cep, String siglaEstado, String nomeMunicipio, String nomeBairro, String nomeLogradouro) {
		this.id = id;
		this.cep = cep;
		this.siglaEstado = siglaEstado;
		this.nomeMunicipio = nomeMunicipio;
		this.nomeBairro = nomeBairro;
		this.nomeLogradouro = nomeLogradouro;
	}

	// --- Getters e Setters (sem alterações) ---

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getSiglaEstado() {
		return siglaEstado;
	}

	public void setSiglaEstado(String siglaEstado) {
		this.siglaEstado = siglaEstado;
	}

	public String getNomeMunicipio() {
		return nomeMunicipio;
	}

	public void setNomeMunicipio(String nomeMunicipio) {
		this.nomeMunicipio = nomeMunicipio;
	}

	public String getNomeBairro() {
		return nomeBairro;
	}

	public void setNomeBairro(String nomeBairro) {
		this.nomeBairro = nomeBairro;
	}

	public String getNomeLogradouro() {
		return nomeLogradouro;
	}

	public void setNomeLogradouro(String nomeLogradouro) {
		this.nomeLogradouro = nomeLogradouro;
	}

	/**
	 * ADIÇÃO: Método toString().
	 * Gera uma representação em texto do objeto, muito útil para depuração e logs.
	 * Ex: System.out.println(meuEndereco);
	 */
	@Override
	public String toString() {
		return "Enderecamento{" +
				"id=" + id +
				", cep='" + cep + '\'' +
				", siglaEstado='" + siglaEstado + '\'' +
				", nomeMunicipio='" + nomeMunicipio + '\'' +
				", nomeBairro='" + nomeBairro + '\'' +
				", nomeLogradouro='" + nomeLogradouro + '\'' +
				'}';
	}


	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Enderecamento that = (Enderecamento) o;
		return Objects.equals(id, that.id);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
}