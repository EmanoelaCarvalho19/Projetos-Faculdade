package br.com.unisenai.ProjetoContas;

import Controller.PessoaController;
import Modelos.Pessoa;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class PessoaTest {

    private static final PessoaController dao = new PessoaController();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;

        while (opcao != 0) {
            exibirMenu();
            try {
                opcao = scanner.nextInt();
                scanner.nextLine();

                switch (opcao) {
                    case 1:
                        listarTodos();
                        break;
                    case 2:
                        buscarPorId();
                        break;
                    case 3:
                        inserirNovo();
                        break;
                    case 4:
                        atualizarExistente();
                        break;
                    case 5:
                        deletar();
                        break;
                    case 0:
                        System.out.println("\n👋 Encerrando o sistema. Até logo!");
                        break;
                    default:
                        System.out.println("\n❌ Opção inválida! Por favor, tente novamente.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("\n❌ Erro de entrada! Por favor, digite apenas números.");
                scanner.nextLine();
                opcao = -1;
            }
            if (opcao != 0) {
                pressioneEnterParaContinuar();
            }
        }
        scanner.close();
    }
    
    private static void exibirMenu() {
        System.out.println("\n--- 👥 MENU DE GERENCIAMENTO DE PESSOAS ---");
        System.out.println("1. Listar todas as pessoas");
        System.out.println("2. Buscar pessoa por ID");
        System.out.println("3. Inserir nova pessoa");
        System.out.println("4. Atualizar pessoa existente");
        System.out.println("5. Deletar pessoa");
        System.out.println("------------------------------------------");
        System.out.println("0. Sair");
        System.out.print("➡️  Escolha uma opção: ");
    }

    private static void listarTodos() {
        System.out.println("\n--- LISTA DE TODAS AS PESSOAS ---");
        List<Pessoa> pessoas = dao.FindAll();
        if (pessoas.isEmpty()) {
            System.out.println("ℹ️ Nenhuma pessoa cadastrada no momento.");
        } else {
            pessoas.forEach(System.out::println);
        }
    }

    private static void buscarPorId() {
        System.out.print("\nDigite o ID da pessoa: ");
        try {
            Long id = scanner.nextLong();
            scanner.nextLine();
            Pessoa pessoa = dao.Find(id);
            if (pessoa != null) {
                System.out.println("✅ Pessoa encontrada:\n" + pessoa);
            } else {
                System.out.println("❌ Pessoa com ID " + id + " não encontrada.");
            }
        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido.");
            scanner.nextLine();
        }
    }
    
    private static void inserirNovo() {
        System.out.println("\n--- INSERIR NOVA PESSOA ---");
        Pessoa novaPessoa = new Pessoa();
        
        try {
            System.out.println("ℹ️ É necessário associar um endereço existente.");
            System.out.print("Digite o ID do Endereçamento: ");
            novaPessoa.setIdEnderecamento(scanner.nextLong());
            scanner.nextLine();
            
            System.out.print("Número do endereço (ex: 550, S/N): ");
            novaPessoa.setNumeroEndereco(scanner.nextLine());
            
            System.out.print("Complemento (opcional): ");
            novaPessoa.setComplementoEndereco(scanner.nextLine());
            
            System.out.print("Telefone (opcional): ");
            novaPessoa.setTelefone(scanner.nextLine());
            
            System.out.print("Cliente desde (formato AAAA-MM-DD): ");
            String dataStr = scanner.nextLine();
            novaPessoa.setClienteDesde(converterStringParaSqlDate(dataStr));

            // A situação pode ser definida como 'Ativo' por padrão
            novaPessoa.setSituacao("Ativo");
            
            Pessoa pessoaSalva = dao.Save(novaPessoa);
            System.out.println("\n✅ Pessoa inserida com sucesso!\n" + pessoaSalva);
            
        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido. A operação foi cancelada.");
            scanner.nextLine();
        } catch (ParseException e) {
            System.out.println("❌ Formato de data inválido! Use AAAA-MM-DD. A operação foi cancelada.");
        }
    }
    
    private static void atualizarExistente() {
        System.out.print("\nDigite o ID da pessoa que deseja atualizar: ");
        try {
            Long id = scanner.nextLong();
            scanner.nextLine();
            
            Pessoa pessoa = dao.Find(id);
            if (pessoa == null) {
                System.out.println("❌ Pessoa com ID " + id + " não encontrada.");
                return;
            }
            
            System.out.println("\n📝 Editando a pessoa (deixe em branco para não alterar):");

            // Exemplo de como atualizar alguns campos. Pode ser expandido para todos.
            System.out.print("Novo telefone (" + pessoa.getTelefone() + "): ");
            String telefone = scanner.nextLine();
            if (!telefone.trim().isEmpty()) {
                pessoa.setTelefone(telefone);
            }
            
            System.out.print("Nova situação (Ativo/Inativo) (" + pessoa.getSituacao() + "): ");
            String situacao = scanner.nextLine();
            if (!situacao.trim().isEmpty()) {
                pessoa.setSituacao(situacao);
            }
            
            dao.Save(pessoa);
            System.out.println("\n✅ Pessoa atualizada com sucesso!");
            
        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido.");
            scanner.nextLine();
        }
    }
    
    private static void deletar() {
         System.out.print("\nDigite o ID da pessoa que deseja deletar: ");
        try {
            Long id = scanner.nextLong();
            scanner.nextLine();
            
            Pessoa pessoa = dao.Find(id);
            if (pessoa == null) {
                System.out.println("❌ Pessoa com ID " + id + " não encontrada.");
                return;
            }

            System.out.println("Você tem certeza que deseja deletar a seguinte pessoa?");
            System.out.println(pessoa);
            System.out.print("Digite 'S' para confirmar: ");
            String confirmacao = scanner.nextLine();
            
            if (confirmacao.equalsIgnoreCase("S")) {
                dao.Delete(id);
                System.out.println("✅ Pessoa deletada com sucesso.");
            } else {
                System.out.println("ℹ️ Operação cancelada.");
            }
        } catch (InputMismatchException e) {
            System.out.println("❌ ID inválido.");
            scanner.nextLine();
        }
    }
    
    private static Date converterStringParaSqlDate(String dataStr) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date parsed = format.parse(dataStr);
        return new java.sql.Date(parsed.getTime());
    }

    private static void pressioneEnterParaContinuar() {
        System.out.print("\nPressione [Enter] para continuar...");
        scanner.nextLine();
    }
}
